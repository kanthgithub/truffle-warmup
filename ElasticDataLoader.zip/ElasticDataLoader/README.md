# ElasticDataLoader


string length <=40

http://localhost:8081/isStringValid/string=

{"response" : true}

{"response" : false}
package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.CreateCommand;

import java.util.Scanner;

public class CreateConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner)
  {
    Integer width = null;
    Integer height = null;

    StringBuilder messageBuilder = new StringBuilder();

    try {
      if(scanner.hasNextInt()){
          width = scanner.nextInt();
      }else{
        messageBuilder.append(" Invalid width for Console Creation ");
      }

      if(width!=null && scanner.hasNextInt()){
          height = scanner.nextInt();
      }else{
        if(width!=null && (!scanner.hasNext() || !scanner.hasNextInt())) {
          messageBuilder.append(" Invalid height for Console Creation ");
        }
      }

    }catch (Exception ex){
      messageBuilder.append(" Invalid dimensions for Console Creation - Failed to parse arguments : Please pass correct arguments ");
    }

    if(messageBuilder.length()>0){
      throw new IllegalArgumentException(messageBuilder.toString());
    }


    return new CreateCommand(width, height);
  }
}

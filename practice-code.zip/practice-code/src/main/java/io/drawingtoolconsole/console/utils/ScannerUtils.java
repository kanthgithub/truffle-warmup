package io.drawingtoolconsole.console.utils;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Scanner;

public class ScannerUtils {

    public static Scanner generateScannerWithData(String data) {
        Scanner scanner;InputStream stdin = System.in;
        try {
            System.setIn(new ByteArrayInputStream(data.getBytes()));
            scanner = new Scanner(System.in);
            scanner.next();
        } finally {
            System.setIn(stdin);
        }
        return scanner;
    }
}

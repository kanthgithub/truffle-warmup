package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;

import java.util.Scanner;

public interface ConsoleCommandArgumentEnricher
{
  Command enrichCommandWithScannerArguments(Scanner scanner);
}

package io.drawingtoolconsole.console.controller;

import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import io.drawingtoolconsole.console.service.DrawingToolCommandExecutionService;
import lombok.Getter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

@Component
@Getter
public class DrawingToolCommandController {

    private DrawingToolCommandExecutionService drawingToolCommandExecutionService;

    private List<String> renderedShapesOnCanvas;

    @Autowired
    public DrawingToolCommandController(DrawingToolCommandExecutionService drawingToolCommandExecutionService) {
        this.drawingToolCommandExecutionService = drawingToolCommandExecutionService;
    }

    public void executeCommandsFromScanner(Scanner scanner) {

        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.ALIEN;

        renderedShapesOnCanvas = new ArrayList<>();

        do {
            System.out.print("enter command:");
            try {
                drawingToolConsoleCommand = DrawingToolConsoleCommand.parse(scanner.next());
                StringBuilder sb = drawingToolCommandExecutionService.executeDrawingCommand(scanner, drawingToolConsoleCommand);
                System.out.println(sb);
                renderedShapesOnCanvas.add(sb.toString());
            }
            catch (Exception ex) {
                renderedShapesOnCanvas.add(ex.getMessage());
                System.out.println(ex.getMessage());
            }
        } while (drawingToolConsoleCommand != DrawingToolConsoleCommand.QUIT);
    }

}

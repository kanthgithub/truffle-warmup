package io.drawingtoolconsole.console.service;

import io.drawingtoolconsole.console.DrawingToolConsoleCommand;

import java.util.Scanner;

public interface DrawingToolCommandExecutionService {

    /**
     *
     * @param scanner
     * @param drawingToolConsoleCommand
     * @return StringBuilder
     */
     StringBuilder executeDrawingCommand(Scanner scanner,
                                               DrawingToolConsoleCommand drawingToolConsoleCommand);
}

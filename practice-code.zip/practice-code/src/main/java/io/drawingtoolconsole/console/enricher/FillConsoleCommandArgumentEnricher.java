package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.FillCommand;

import java.util.Scanner;

public class FillConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner)
  {
     Integer xCoordinate = null;
     Integer yCoordinate = null;
     char color = 0;

     StringBuilder messageBuilder = new StringBuilder();

      try {
            if(scanner.hasNextInt()){
              xCoordinate = scanner.nextInt();
            }else{
              messageBuilder.append(" Invalid xCoordinate for Fill ");
            }

            if(xCoordinate!=null && scanner.hasNextInt()){
              yCoordinate = scanner.nextInt();
            }else{
              if(xCoordinate!=null && (!scanner.hasNext() || !scanner.hasNextInt())) {
                messageBuilder.append(" Invalid yCoordinate for Fill ");
              }
            }

          if(yCoordinate!=null && scanner.hasNext()) {
              color = scanner.next().charAt(0);
          }else{
              if(yCoordinate!=null && (!scanner.hasNext() )) {
                  messageBuilder.append(" Invalid color for Fill ");
              }
          }

      }catch (Exception ex){
          messageBuilder.append(" Invalid Coordinates for Fill - Failed to parse arguments : Please correct arguments ");
      }

      if(messageBuilder.length()>0){
          throw new IllegalArgumentException(messageBuilder.toString());
      }


    return new FillCommand(xCoordinate, yCoordinate, color);
  }
}

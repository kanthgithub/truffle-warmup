package io.drawingtoolconsole;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DrawingToolConsoleApplication {

    public static void main(String[] args) {
        SpringApplication.run(DrawingToolConsoleApplication.class, args);
    }
}
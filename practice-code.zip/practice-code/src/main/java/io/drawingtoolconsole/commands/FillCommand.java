package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;
import lombok.*;


@Getter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
public class FillCommand implements Command
{
  private  int xCoordinate;
  private int yCoordinate;
  private char color;

  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {
    canvasRenderer.fillCoordinatesWithCharacters(xCoordinate, yCoordinate, color);
  }

}

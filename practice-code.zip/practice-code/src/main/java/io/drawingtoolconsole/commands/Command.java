package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;

public interface Command
{
  void execute(CanvasRenderer canvasRenderer);
}

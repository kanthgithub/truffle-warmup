package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;

public class QuitCommand implements Command
{

  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {

  }
}

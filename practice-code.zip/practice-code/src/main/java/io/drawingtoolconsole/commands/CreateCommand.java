package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;
import lombok.*;

@Getter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
public class CreateCommand implements Command
{
  private int width;
  private int height;

  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {
    canvasRenderer.createCanvas(width, height);
  }

}

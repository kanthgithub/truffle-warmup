package io.drawingtoolconsole.model;

import lombok.*;

@Getter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
public class Rectangle implements Shape
{
  private final static char FILL_CHARACTER = 'x';

  private Integer xCoordinate1;
  private Integer yCoordinate1;
  private Integer xCoordinate2;
  private Integer yCoordinate2;

    /**
     * Adds Rectangle to canvas
     *
     * @param drawingCanvas
     */
  @Override
  public void addShapeTo(DrawingCanvas drawingCanvas)
  {
    if (!validRectangleOnCanvas(drawingCanvas.width(),drawingCanvas.height())) {
        throw new IllegalArgumentException("Invalid rectangle.");
    }

    // horizontal lines
    for (int horizontalLineIndex = 0; horizontalLineIndex < width(); horizontalLineIndex++) {
      drawingCanvas.generateLineWithFillCharacter(xCoordinate1 + horizontalLineIndex, yCoordinate1, FILL_CHARACTER);
    }
    for (int horizontalLineIndex = 0; horizontalLineIndex < width(); horizontalLineIndex++) {
      drawingCanvas.generateLineWithFillCharacter(xCoordinate1 + horizontalLineIndex, yCoordinate2, FILL_CHARACTER);
    }

    // vertical lines
    for (int verticalLineIndex = 0; verticalLineIndex < height() - 2; verticalLineIndex++) {
      drawingCanvas.generateLineWithFillCharacter(xCoordinate1, yCoordinate1 + verticalLineIndex + 1, FILL_CHARACTER);
    }
    for (int verticalLineIndex = 0; verticalLineIndex < height() - 2; verticalLineIndex++) {
      drawingCanvas.generateLineWithFillCharacter(xCoordinate2, yCoordinate1 + verticalLineIndex + 1, FILL_CHARACTER);
    }
  }

  public Integer height()
  {
    return yCoordinate2 - yCoordinate1 + 1;
  }

  public Integer width()
  {
    return xCoordinate2 - xCoordinate1 + 1;
  }

  public Boolean validRectangleOnCanvas(Integer canvasWidth,Integer canvasHeight)
  {
    Boolean isAValidBuildOfRectangleOnCanvas = Boolean.TRUE;


    if (xCoordinate1 < 0 || xCoordinate1 > xCoordinate2 || yCoordinate1 < 0 || yCoordinate1 > yCoordinate2 ||
            xCoordinate2 > canvasWidth || yCoordinate2 > canvasHeight) {
      isAValidBuildOfRectangleOnCanvas = false;
    }

    return isAValidBuildOfRectangleOnCanvas;
  }
}

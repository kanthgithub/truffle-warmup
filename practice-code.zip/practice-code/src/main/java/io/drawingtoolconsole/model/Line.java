package io.drawingtoolconsole.model;

import lombok.*;

@Getter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
public class Line implements Shape
{
  private final static char FILL_CHARACTER = 'x';

  private Integer xCoordinate1;
  private Integer yCoordinate1;
  private Integer xCoordinate2;
  private Integer yCoordinate2;

  /**
   *
   * adds Line to Canvas
   *
   * @param drawingCanvas
   */
  @Override
  public void addShapeTo(DrawingCanvas drawingCanvas)
  {
    if (!validLineOnCanvas(drawingCanvas.width(),drawingCanvas.height())) {
      throw new IllegalArgumentException("Invalid line!");
    }

    Integer lineLength = length();

    if (isHorizontal()) {
      for (int canvasIndex = 0; canvasIndex <= lineLength; canvasIndex++) {
        drawingCanvas.generateLineWithFillCharacter(xCoordinate1 + canvasIndex, yCoordinate1, FILL_CHARACTER);
      }
    }
    else {
      for (int canvasIndex = 0; canvasIndex <= lineLength; canvasIndex++) {
        drawingCanvas.generateLineWithFillCharacter(xCoordinate1, yCoordinate1 + canvasIndex, FILL_CHARACTER);
      }
    }
  }


  public Integer length()
  {
    Integer lineLength;

    if (isHorizontal()) {
      lineLength = xCoordinate2 - xCoordinate1;
    }
    else {
      lineLength = yCoordinate2 - yCoordinate1;
    }

    return lineLength;
  }

  /**
   *
   * @param canvasWidth
   * @param canvasHeight
   * @return Boolean
   */
  public Boolean validLineOnCanvas(Integer canvasWidth,Integer canvasHeight)
  {
    Boolean isValid = Boolean.TRUE;

    // is line aligned with-in canvas coordinates?
    if (xCoordinate1 < 0 || yCoordinate1 < 0 || xCoordinate2 > canvasWidth || yCoordinate2 > canvasHeight) {
      isValid = false;
    }
    
    // is this a diagonal line?
    if (xCoordinate1 != xCoordinate2 && yCoordinate1 != yCoordinate2) {
      isValid = false;
    }

    return isValid;
  }

  public boolean isHorizontal()
  {
    return yCoordinate1 == yCoordinate2;
  }
}

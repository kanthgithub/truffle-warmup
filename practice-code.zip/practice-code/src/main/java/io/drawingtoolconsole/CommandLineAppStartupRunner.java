package io.drawingtoolconsole;

import io.drawingtoolconsole.console.controller.DrawingToolCommandController;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Scanner;

import static io.drawingtoolconsole.console.utils.ScannerUtils.generateScannerWithData;


@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(CommandLineAppStartupRunner.class);

    @Autowired
    DrawingToolCommandController drawingToolCommandController;

    Boolean isOnTestMode;

    @Autowired
    public CommandLineAppStartupRunner(DrawingToolCommandController drawingToolCommandController,Boolean isOnTestMode) {
        this.drawingToolCommandController = drawingToolCommandController;
        this.isOnTestMode = isOnTestMode;
    }

    @Override
    public void run(String... args) {

        logger.info(
                "Application started with command-line arguments: {} . \n To kill this application, press Ctrl + C.",
                Arrays.toString(args));

        Scanner scanner = null;

        if(isOnTestMode){
            logger.info("ON TEST MODE");
            scanner = generateScannerWithData( System.getProperty("scannerTestCommands"));
        }else{
            scanner = new Scanner(System.in);
        }

        drawingToolCommandController.executeCommandsFromScanner(scanner);

        scanner.close();

        System.exit(0);
    }
}
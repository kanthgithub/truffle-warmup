package io.drawingtoolconsole;

import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class CanvasRendererTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    @Test
    public void assert_Create_Canvas(){

        //given
        Integer canvas_Width = 12;
        Integer canvas_Height = 20;

        //when
        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        //then
        canvasRenderer.handleCanvasValidityCheck();
    }

    @Test
    public void assert_Canvas_Validity_To_Failure(){

        //given
        String expectedErrorMessage = "Invalid DrawingCanvas. DrawingCanvas cannot be empty.";
        Exception actualException = null;

        //when
        try {
            canvasRenderer.handleCanvasValidityCheck();
        }catch (Exception ex){
            actualException = ex;
        }

        //then
        assertNotNull(actualException);
        assertTrue(actualException instanceof IllegalStateException);
        assertEquals(expectedErrorMessage, actualException.getMessage() );
    }

    @Test
    public void assert_Create_Canvas_Failure_With_Invalid_Coordinates(){

        //given
        Integer canvas_Width = -1;
        Integer canvas_Height = 20;

        String expectedErrorMessage = "DrawingCanvas dimensions must be positive";

        Exception exception_Actual = null;

        //when
        try {
            canvasRenderer.createCanvas(canvas_Width, canvas_Height);
        }catch (Exception ex){
            exception_Actual = ex;
        }

        //then
        assertNotNull(exception_Actual);
        assertNotNull(exception_Actual.getMessage());
        assertEquals(expectedErrorMessage,exception_Actual.getMessage());
    }

    @Test
    public void assert_Canvas_Rendering(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Integer canvas_Width = 12;
        Integer canvas_Height = 20;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        canvasRenderer.addLine(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);

        //when
        StringBuilder lineRendered_Actual = canvasRenderer.renderAsAString();

        String lineRendered_Expected =
                "--------------\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "______________";

        //then
        assertNotNull(lineRendered_Actual);
        assertEquals(lineRendered_Expected,lineRendered_Actual.toString() );
    }

    @Test
    public void assert_Canvas_Rendering_Output_From_Multiple_Commands(){

        //given
        Integer xCoordinate1_Line = 1;
        Integer yCoordinate1_Line = 2;
        Integer xCoordinate2_Line = 6;
        Integer yCoordinate2_Line = 2;

        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        canvasRenderer.addLine(xCoordinate1_Line, yCoordinate1_Line, xCoordinate2_Line, yCoordinate2_Line);

        Integer xCoordinate1_Rectangle = 16;
        Integer yCoordinate1_Rectangle = 1;
        Integer xCoordinate2_Rectangle = 20;
        Integer yCoordinate2_Rectangle = 3;

        canvasRenderer.addRectangle(xCoordinate1_Rectangle,yCoordinate1_Rectangle,xCoordinate2_Rectangle,yCoordinate2_Rectangle);


        //when
        StringBuilder rendered_Actual = canvasRenderer.renderAsAString();

        String rendered_Expected =
                "----------------------\n" +
                "|               xxxxx|\n" +
                "|xxxxxx         x   x|\n" +
                "|               xxxxx|\n" +
                "|                    |\n" +
                "______________________";

        //then
        assertNotNull(rendered_Actual);
        assertEquals(rendered_Expected,rendered_Actual.toString() );
    }

    @Test
    public void assert_Canvas_Rendering_To_Fill_Characters_Witin_Coordinates(){

        //given
        Integer xCoordinate1_Line = 1;
        Integer yCoordinate1_Line = 2;
        Integer xCoordinate2_Line = 6;
        Integer yCoordinate2_Line = 2;

        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        canvasRenderer.addLine(xCoordinate1_Line, yCoordinate1_Line, xCoordinate2_Line, yCoordinate2_Line);

        Integer xCoordinate_FillCharacters = 16;
        Integer yCoordinate_FillCharacters = 1;
        char fillCharacter = 'u';

        canvasRenderer.fillCoordinatesWithCharacters(xCoordinate_FillCharacters,yCoordinate_FillCharacters,fillCharacter);


        //when
        StringBuilder rendered_Actual = canvasRenderer.renderAsAString();

        String rendered_Expected =
                        "----------------------\n" +
                        "|uuuuuuuuuuuuuuuuuuuu|\n" +
                        "|xxxxxxuuuuuuuuuuuuuu|\n" +
                        "|uuuuuuuuuuuuuuuuuuuu|\n" +
                        "|uuuuuuuuuuuuuuuuuuuu|\n" +
                        "______________________";

        //then
        assertNotNull(rendered_Actual);
        assertEquals(rendered_Expected,rendered_Actual.toString() );
    }

    @Test
    public void assert_Canvas_Rendering_To_Fill_Characters_With_Invalid_Coordinates(){

        //given
        Integer xCoordinate1_Line = 1;
        Integer yCoordinate1_Line = 2;
        Integer xCoordinate2_Line = 6;
        Integer yCoordinate2_Line = 2;

        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        canvasRenderer.addLine(xCoordinate1_Line, yCoordinate1_Line, xCoordinate2_Line, yCoordinate2_Line);

        Integer xCoordinate_FillCharacters = 0;
        Integer yCoordinate_FillCharacters = -1;
        char fillCharacter = 'u';

        Exception actualException = null;

        String expectedErrorMessage = "renderer should render within drawingCanvas limits.";

        //when
        try {
            canvasRenderer.fillCoordinatesWithCharacters(xCoordinate_FillCharacters, yCoordinate_FillCharacters, fillCharacter);
        }catch (Exception ex){
            actualException = ex;
        }

        //then
        assertNotNull(actualException);
        assertTrue(actualException instanceof IllegalArgumentException);
        assertNotNull(actualException.getMessage());
        assertEquals(expectedErrorMessage,actualException.getMessage() );
    }



    public void createCanvas_With_Parameters(Integer width,Integer height){
        canvasRenderer.createCanvas(width, height);
    }



}

package io.drawingtoolconsole.cucumber.stepDefs;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Ignore;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {
        DrawingConsoleToolApplicationTestConfiguration.class})
@SpringBootTest(webEnvironment = RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@Ignore
public class DrawingConsoleToolStepDefinition  {

    Scenario currentScenario;

    @Before
    public void setup(Scenario scenario) throws Exception {
        currentScenario = scenario;
    }

    @When("^I Execute Command$")
    public void i_Execute_Command() {

    }

    @Then("^Response should contain (.*)$")
    public void responseShouldContain(String responseString) throws Throwable {

    }


}

package io.drawingtoolconsole.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class LineTest {

    @Test
    public void assert_Add_Line_to_Canvas(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //given
        Integer width = 10;
        Integer height = 12;

        String expectedRenderedString = "------------\n" +
                "|          |\n" +
                "|          |\n" +
                "|          |\n" +
                "|          |\n" +
                "|          |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "| x        |\n" +
                "____________";

        //when
        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);


        //when
        line.addShapeTo(drawingCanvas);
        StringBuilder renderedLineAsString = drawingCanvas.render();

        //then
        assertNotNull(renderedLineAsString);
        assertEquals(expectedRenderedString,renderedLineAsString.toString());
        assertEquals(xCoordinate1,line.getXCoordinate1());
        assertEquals(yCoordinate1,line.getYCoordinate1());
        assertEquals(xCoordinate2,line.getXCoordinate2());
        assertEquals(yCoordinate2,line.getYCoordinate2());
        assertEquals("Line(xCoordinate1=2, yCoordinate1=6, xCoordinate2=2, yCoordinate2=12)",line.toString());
        assertEquals(12549135,line.hashCode());
        assertEquals(new Line(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2),line);

    }

    @Test
    public void assert_Add_Line_With_NonAligned_Coordinates_to_Canvas(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 112;
        Integer yCoordinate2 = 12;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //given
        Integer width = 10;
        Integer height = 12;

        //when
        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);

        String expectedMessage = "Invalid line!";

        Exception actualException = null;

        //when
        try{
            line.addShapeTo(drawingCanvas);
        }catch (Exception ex){
            actualException = ex;
        }

        //then
        assertNotNull(actualException);
        assertTrue(actualException instanceof  IllegalArgumentException);
        assertEquals(expectedMessage,actualException.getMessage() );
    }

    @Test
    public void assert_Line_Alignment_On_Canvas(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //given
        Integer width = 10;
        Integer height = 12;

        //when
        Boolean isLineValid_Actual = line.validLineOnCanvas(width,height);

        //then
        assertNotNull(isLineValid_Actual);
        assertTrue(isLineValid_Actual);
    }

    @Test
    public void assert_For_NonAligned_Line_On_Canvas(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 100;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        Integer canvas_width = 10;
        Integer canvas_height = 12;

        //when
        Boolean isLineValid_Actual = line.validLineOnCanvas(canvas_width,canvas_height);

        //then
        assertNotNull(isLineValid_Actual);
        assertFalse(isLineValid_Actual);
    }

    @Test
    public void assert_For_Line_Length(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        Integer lineLength_Actual = line.length();

        //then
        assertNotNull(lineLength_Actual);
        assertEquals(6,lineLength_Actual.intValue());
    }

    @Test
    public void assert_For_Horizontal_Line(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 7;
        Integer yCoordinate2 = 6;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        Boolean isAHorizontalLine = line.isHorizontal();

        //then
        assertNotNull(isAHorizontalLine);
        assertTrue(isAHorizontalLine);
    }

    @Test
    public void assert_For_Non_Horizontal_Line(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 7;
        Integer yCoordinate2 = 10;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        Boolean isAHorizontalLine = line.isHorizontal();

        //then
        assertNotNull(isAHorizontalLine);
        assertFalse(isAHorizontalLine);
    }

    @Test
    public void assert_Validation_Failure_For_Diagonal_Line(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 7;
        Integer yCoordinate2 = 10;

        Line line = getLineWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        Integer canvas_width = 10;
        Integer canvas_height = 12;

        //when
        Boolean isDiagonalLineAValidLine = line.validLineOnCanvas(canvas_width, canvas_height);

        //then
        assertNotNull(isDiagonalLineAValidLine);
        assertFalse(isDiagonalLineAValidLine);
    }

    public Line getLineWithCoordinates(Integer xCoordinate1, Integer yCoordinate1,
                                       Integer xCoordinate2, Integer yCoordinate2){

        return new Line(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);
    }

    public DrawingCanvas getADrawingCanvasFromParameters(Integer width, Integer height){

        return new DrawingCanvas(width,height);
    }
}

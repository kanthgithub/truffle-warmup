package io.drawingtoolconsole.model;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class RectangleTest {

    @Test
    public void assert_Add_Rectangle_to_Canvas(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 3;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //given
        Integer canvas_Width = 20;
        Integer canvas_Height = 4;


        String expectedRenderedString =
                "----------------------\n" +
                "|               xxxxx|\n" +
                "|               x   x|\n" +
                "|               xxxxx|\n" +
                "|                    |\n" +
                "______________________";
        //when
        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(canvas_Width,canvas_Height);

        //when
        rectangle.addShapeTo(drawingCanvas);
        StringBuilder renderedRectangleAsString = drawingCanvas.render();

        //then
        assertNotNull(renderedRectangleAsString);
        assertEquals(expectedRenderedString,renderedRectangleAsString.toString());
        assertEquals(xCoordinate1,rectangle.getXCoordinate1());
        assertEquals(yCoordinate1,rectangle.getYCoordinate1());
        assertEquals(xCoordinate2,rectangle.getXCoordinate2());
        assertEquals(yCoordinate2,rectangle.getYCoordinate2());
        assertEquals("Rectangle(xCoordinate1=16, yCoordinate1=1, xCoordinate2=20, yCoordinate2=3)",rectangle.toString());
        assertEquals(15408089,rectangle.hashCode());
        assertEquals(new Rectangle(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2),rectangle);
    }


    @Test
    public void assert_Add_Rectangle_In_NonAligned_Coordinates_to_Canvas(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 100;
        Integer xCoordinate2 = 200;
        Integer yCoordinate2 = 3;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //given
        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(canvas_Width,canvas_Height);

        Exception actualException = null;
        String expectedMessage = "Invalid rectangle.";

        //when
        try{
        rectangle.addShapeTo(drawingCanvas);
        }catch (Exception ex){
            actualException = ex;
        }

        //then
        assertNotNull(actualException);
        assertTrue(actualException instanceof  IllegalArgumentException);
        assertEquals(expectedMessage,actualException.getMessage() );
    }

    @Test
    public void assert_Validation_For_Rectangle(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 3;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        Integer canvas_width = 20;
        Integer canvas_height = 4;

        //when
        Boolean isAValidRectangleOnCanvas = rectangle.validRectangleOnCanvas(canvas_width, canvas_height);

        //then
        assertNotNull(isAValidRectangleOnCanvas);
        assertTrue(isAValidRectangleOnCanvas);
    }

    @Test
    public void assert_For_NonAligned_Rectangle_On_Canvas(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 300;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        Integer canvas_width = 20;
        Integer canvas_height = 4;

        //when
        Boolean isAValidRectangleOnCanvas = rectangle.validRectangleOnCanvas(canvas_width, canvas_height);

        //then
        assertNotNull(isAValidRectangleOnCanvas);
        assertFalse(isAValidRectangleOnCanvas);
    }

    @Test
    public void assert_get_Rectangle_Width(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 3;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        Integer rectangleWidth = rectangle.width();

        //then
        assertNotNull(rectangleWidth);
        assertEquals(5,rectangleWidth.intValue());
    }

    @Test
    public void assert_get_Rectangle_Height(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 3;

        Rectangle rectangle = getRectangleWithCoordinates(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        Integer rectangleHeight = rectangle.height();

        //then
        assertNotNull(rectangleHeight);
        assertEquals(3,rectangleHeight.intValue());
    }

    public Rectangle getRectangleWithCoordinates(Integer xCoordinate1, Integer yCoordinate1,
                                       Integer xCoordinate2, Integer yCoordinate2){

        return new Rectangle(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);
    }

    public DrawingCanvas getADrawingCanvasFromParameters(Integer width, Integer height){

        return new DrawingCanvas(width,height);
    }
}

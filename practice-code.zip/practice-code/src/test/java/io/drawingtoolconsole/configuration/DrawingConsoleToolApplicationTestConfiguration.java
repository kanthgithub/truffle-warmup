package io.drawingtoolconsole.configuration;

import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.console.controller.DrawingToolCommandController;
import io.drawingtoolconsole.console.enricher.ConsoleCommandArgumentEnricherFactory;
import io.drawingtoolconsole.console.service.DrawingToolCommandExecutionService;
import io.drawingtoolconsole.console.service.DrawingToolCommandExecutionServiceImpl;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.FilterType;

@Configuration
@ComponentScan(excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CommandLineRunner.class))
@EnableAutoConfiguration
public class DrawingConsoleToolApplicationTestConfiguration extends DrawingToolConsoleConfiguration{

    @Bean
    public DrawingToolCommandExecutionService drawingToolCommandExecutionService(ConsoleCommandArgumentEnricherFactory consoleCommandArgumentEnricherFactory,
                                                                                 CanvasRenderer canvasRenderer){
        return  new DrawingToolCommandExecutionServiceImpl(consoleCommandArgumentEnricherFactory,canvasRenderer);
    }

    @Bean
    public DrawingToolCommandController drawingToolCommandController(DrawingToolCommandExecutionService drawingToolCommandExecutionService){
        return new DrawingToolCommandController(drawingToolCommandExecutionService);
    }
}
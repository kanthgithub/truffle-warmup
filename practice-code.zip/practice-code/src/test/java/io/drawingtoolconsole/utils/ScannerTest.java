package io.drawingtoolconsole.utils;

import org.junit.Test;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;

public class ScannerTest {

    @Test
    public void assert_Multiple_Commands_In_Scanner(){

        //given
        String canvasData = "Start \n C 20 4 \n L 1 2 6 2 \n R 16 1 20 3 \n Q";

        Scanner scanner = generateScannerWithTestData(canvasData);

        //when
        do{
            System.out.println(scanner.next());
        }while(scanner.hasNext());


    }



}

package io.drawingtoolconsole.commands;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class CreateCommandTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    CreateCommand createCommand;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
        createCommand = null;
    }


    @Test
    public void assert_Create_Command_Execution(){

        //given

        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        createCommand = new CreateCommand(canvas_Width,canvas_Height);

        //when
        createCommand.execute(canvasRenderer);

        //then
        StringBuilder stringBuilder_Actual = canvasRenderer.renderAsAString();

        String expectedRenderedString =
                                       "----------------------\n" +
                                       "|                    |\n" +
                                       "|                    |\n" +
                                       "|                    |\n" +
                                       "|                    |\n" +
                                       "______________________";

        assertNotNull(stringBuilder_Actual);
        assertEquals(expectedRenderedString,stringBuilder_Actual.toString());
        assertNotNull(createCommand);
        assertEquals(canvas_Height.intValue(),createCommand.getHeight() );
        assertEquals(canvas_Width.intValue(),createCommand.getWidth() );
        assertEquals("CreateCommand(width=20, height=4)",createCommand.toString() );
        assertEquals(4665,createCommand.hashCode() );
    }
}

package io.drawingtoolconsole.commands;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class RectangleCommandTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    RectangleCommand rectangleCommand;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
        rectangleCommand = null;
    }


    @Test
    public void assert_Rectangle_Command_Execution(){

        //given
        Integer xCoordinate1 = 16;
        Integer yCoordinate1 = 1;
        Integer xCoordinate2 = 20;
        Integer yCoordinate2 = 3;

        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        rectangleCommand = new RectangleCommand(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        rectangleCommand.execute(canvasRenderer);

        //then
        StringBuilder stringBuilder_Actual = canvasRenderer.renderAsAString();

        String expectedRenderedString =
                       "----------------------\n" +
                       "|               xxxxx|\n" +
                       "|               x   x|\n" +
                       "|               xxxxx|\n" +
                       "|                    |\n" +
                       "______________________";

        assertNotNull(stringBuilder_Actual);
        assertEquals(expectedRenderedString,stringBuilder_Actual.toString());
        assertEquals(xCoordinate1.intValue(),rectangleCommand.getXCoordinate1());
        assertEquals(yCoordinate1.intValue(),rectangleCommand.getYCoordinate1());
        assertEquals(xCoordinate2.intValue(),rectangleCommand.getXCoordinate2());
        assertEquals(yCoordinate2.intValue(),rectangleCommand.getYCoordinate2());
        assertEquals("RectangleCommand(xCoordinate1=16, yCoordinate1=1, xCoordinate2=20, yCoordinate2=3)",rectangleCommand.toString());
        assertEquals(15408089,rectangleCommand.hashCode());
        assertEquals(new RectangleCommand(16,1,20,3),rectangleCommand);

    }
}

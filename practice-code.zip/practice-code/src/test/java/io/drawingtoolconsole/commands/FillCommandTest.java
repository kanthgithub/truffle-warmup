package io.drawingtoolconsole.commands;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class FillCommandTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    FillCommand fillCommand;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
        fillCommand = null;
    }


    @Test
    public void assert_Fill_Command_Execution(){

        //given
        Integer xCoordinate = 16;
        Integer yCoordinate = 1;
        char fillCharacter = '~';


        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        fillCommand = new FillCommand(xCoordinate,yCoordinate,fillCharacter);

        //when
        fillCommand.execute(canvasRenderer);

        //then
        StringBuilder stringBuilder_Actual = canvasRenderer.renderAsAString();

        String expectedRenderedString =
                               "----------------------\n" +
                               "|~~~~~~~~~~~~~~~~~~~~|\n" +
                               "|~~~~~~~~~~~~~~~~~~~~|\n" +
                               "|~~~~~~~~~~~~~~~~~~~~|\n" +
                               "|~~~~~~~~~~~~~~~~~~~~|\n" +
                               "______________________";

        assertNotNull(stringBuilder_Actual);
        assertEquals(expectedRenderedString,stringBuilder_Actual.toString());

        assertEquals(xCoordinate.intValue(),fillCommand.getXCoordinate());
        assertEquals(yCoordinate.intValue(),fillCommand.getYCoordinate());
        assertEquals(fillCharacter,fillCommand.getColor());
        assertEquals("FillCommand(xCoordinate=16, yCoordinate=1, color=~)",fillCommand.toString());
        assertEquals(261260,fillCommand.hashCode());
        assertEquals(new FillCommand(16,1,'~'),fillCommand);

    }
}

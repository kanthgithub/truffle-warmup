package io.drawingtoolconsole.commands;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class LineCommandTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    LineCommand lineCommand;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
        lineCommand = null;
    }


    @Test
    public void assert_Line_Command_Execution(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Integer canvas_Width = 12;
        Integer canvas_Height = 20;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        lineCommand = new LineCommand(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2);

        //when
        lineCommand.execute(canvasRenderer);

        //then
        StringBuilder stringBuilder_Actual = canvasRenderer.renderAsAString();

        String expectedRenderedString =
                "--------------\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "______________";

        assertNotNull(stringBuilder_Actual);
        assertEquals(expectedRenderedString,stringBuilder_Actual.toString());
        assertEquals(xCoordinate1.intValue(),lineCommand.getXCoordinate1());
        assertEquals(yCoordinate1.intValue(),lineCommand.getYCoordinate1());
        assertEquals(xCoordinate2.intValue(),lineCommand.getXCoordinate2());
        assertEquals(yCoordinate2.intValue(),lineCommand.getYCoordinate2());
        assertEquals("LineCommand(xCoordinate1=2, yCoordinate1=6, xCoordinate2=2, yCoordinate2=12)",lineCommand.toString());
        assertEquals(12549135,lineCommand.hashCode());
        assertEquals(new LineCommand(xCoordinate1,yCoordinate1,xCoordinate2,yCoordinate2),lineCommand);

    }
}

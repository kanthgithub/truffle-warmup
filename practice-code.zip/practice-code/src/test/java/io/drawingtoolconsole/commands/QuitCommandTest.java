package io.drawingtoolconsole.commands;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class QuitCommandTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    Scanner scanner;

    Command command_Actual;

    QuitCommand quitCommand;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        quitCommand = null;
    }


    @Test
    public void assert_Quit_Command_Execution(){

        //given
        Integer canvas_Width = 20;
        Integer canvas_Height = 4;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        quitCommand = new QuitCommand();

        //when
        quitCommand.execute(canvasRenderer);

        assertNotNull(quitCommand);
    }
}

package io.drawingtoolconsole.console.service;


import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DrawingToolCommandExecutionServiceImplTest {

    @Autowired
    DrawingToolCommandExecutionService drawingToolCommandExecutionService;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
    }


    @Test
    public void assert_Multiple_Command_Execution_Via_CanvasCreation_And_LineRender(){

      //given
        DrawingToolConsoleCommand createCanvasCommand = DrawingToolConsoleCommand.CREATE;

        String canvasData = "C 20 4";

        scanner = generateScannerWithTestData(canvasData);

        drawingToolCommandExecutionService.executeDrawingCommand(scanner,createCanvasCommand);

        DrawingToolConsoleCommand lineCommandForExecution = DrawingToolConsoleCommand.LINE;

        String data = "L 1 2 6 2";

        scanner = generateScannerWithTestData(data);

        //when
        StringBuilder commandExecutionOutput_Actual =
              drawingToolCommandExecutionService.executeDrawingCommand(scanner,lineCommandForExecution);

        String expectedString =
                "----------------------\n" +
                "|                    |\n" +
                "|xxxxxx              |\n" +
                "|                    |\n" +
                "|                    |\n" +
                "______________________";

        //then
        assertNotNull(commandExecutionOutput_Actual);
        assertEquals(expectedString,commandExecutionOutput_Actual.toString());
    }


    @Test
    public void assert_Multiple_Command_Execution_Via_CanvasCreation_Line_And_RectangleRender(){

        //given
        DrawingToolConsoleCommand createCanvasCommand = DrawingToolConsoleCommand.CREATE;

        String canvasData = "C 20 4";

        scanner = generateScannerWithTestData(canvasData);

        drawingToolCommandExecutionService.executeDrawingCommand(scanner,createCanvasCommand);

        DrawingToolConsoleCommand lineCommandForExecution = DrawingToolConsoleCommand.LINE;

        String lineData = "L 1 2 6 2";

        scanner = generateScannerWithTestData(lineData);

        drawingToolCommandExecutionService.executeDrawingCommand(scanner,lineCommandForExecution);


        DrawingToolConsoleCommand rectangleCommandForExecution = DrawingToolConsoleCommand.RECTANGLE;

        String rectangleData = "R 16 1 20 3";

        scanner = generateScannerWithTestData(rectangleData);

        //when
        StringBuilder commandExecutionOutput_Actual =
                drawingToolCommandExecutionService.executeDrawingCommand(scanner,rectangleCommandForExecution);

        String expectedString =
                               "----------------------\n" +
                               "|               xxxxx|\n" +
                               "|xxxxxx         x   x|\n" +
                               "|               xxxxx|\n" +
                               "|                    |\n" +
                               "______________________";

        //then
        assertNotNull(commandExecutionOutput_Actual);
        assertEquals(expectedString,commandExecutionOutput_Actual.toString());
    }
}

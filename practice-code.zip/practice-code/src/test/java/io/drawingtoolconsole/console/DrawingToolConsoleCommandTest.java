package io.drawingtoolconsole.console;

import org.junit.Test;

import static io.drawingtoolconsole.console.DrawingToolConsoleCommand.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class DrawingToolConsoleCommandTest {

    @Test
    public void assert_All_Commands_In_DrawingToolConsole_Command(){

        //when
        DrawingToolConsoleCommand[] allCommands =
                DrawingToolConsoleCommand.values();

        //then
        assertNotNull(allCommands);
        assertTrue(allCommands.length == 6);
        assertTrue(allCommands[0].equals(CREATE));
        assertTrue(allCommands[1].equals(LINE));
        assertTrue(allCommands[2].equals(RECTANGLE));
        assertTrue(allCommands[3].equals(FILL));
        assertTrue(allCommands[4].equals(QUIT));
        assertTrue(allCommands[5].equals(ALIEN));
    }


    @Test
    public void assert_Parse_Command_String_For_Create_Console_Command(){

        //given
        String consoleCommandString = "C";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(CREATE));
    }

    @Test
    public void assert_Parse_Command_String_For_Line_Console_Command(){

        //given
        String consoleCommandString = "L";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(LINE));
    }


    @Test
    public void assert_Parse_Command_String_For_Rectangle_Console_Command(){

        //given
        String consoleCommandString = "R";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(RECTANGLE));
    }


    @Test
    public void assert_Parse_Command_String_For_Fill_Console_Command(){

        //given
        String consoleCommandString = "B";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(FILL));
    }


    @Test
    public void assert_Parse_Command_String_For_Quit_Console_Command(){

        //given
        String consoleCommandString = "Q";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(QUIT));
    }


    @Test
    public void assert_Parse_Command_String_For_Alien_Console_Command(){

        //given
        String consoleCommandString = "AL";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(ALIEN));
    }


    @Test
    public void assert_Parse_Invalid_Command_String_For_Alien_Console_Command(){

        //given
        String consoleCommandString = "FAKE";

        //when
        DrawingToolConsoleCommand parsedCommand=
                DrawingToolConsoleCommand.parse(consoleCommandString);

        //then
        assertNotNull(parsedCommand);
        assertTrue(parsedCommand.equals(ALIEN));
    }

}

package io.drawingtoolconsole.console.controller;

import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DrawingToolControllerTest {

    @Autowired
    DrawingToolCommandController drawingToolCommandController;

    Scanner scanner;

    @Before
    public void prepareForTests(){
        scanner = null;
    }

    @Test
    public void assert_Multiple_Command_Execution_Via_CanvasCreation_Line_And_RectangleRender(){

        //given
        String canvasData = "Start \n C 20 4 \n L 1 2 6 2 \n L 6 3 6 4 \n R 16 1 20 3 \n B 10 3 o \n Q";

        scanner = generateScannerWithTestData(canvasData);

        //when
        drawingToolCommandController.executeCommandsFromScanner(scanner);

        //then

        assertNotNull(drawingToolCommandController.getDrawingToolCommandExecutionService());

        List<String> renderedShapesOnCanvas = drawingToolCommandController.getRenderedShapesOnCanvas();

        assertNotNull(renderedShapesOnCanvas);
        assertEquals(6,renderedShapesOnCanvas.size());

        //expected Shape Data Assertion

        String shape_1 = "----------------------\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(0));
        assertEquals(shape_1,renderedShapesOnCanvas.get(0));


        String shape_2 = "----------------------\n" +
                        "|                    |\n" +
                        "|xxxxxx              |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(1));
        assertEquals(shape_2,renderedShapesOnCanvas.get(1));


        String shape_3 = "----------------------\n" +
                        "|                    |\n" +
                        "|xxxxxx              |\n" +
                        "|     x              |\n" +
                        "|     x              |\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(2));
        assertEquals(shape_3,renderedShapesOnCanvas.get(2));


        String shape_4 =    "----------------------\n" +
                            "|               xxxxx|\n" +
                            "|xxxxxx         x   x|\n" +
                            "|     x         xxxxx|\n" +
                            "|     x              |\n" +
                            "______________________";

        assertNotNull(renderedShapesOnCanvas.get(3));
        assertEquals(shape_4,renderedShapesOnCanvas.get(3));


        String shape_5 = "----------------------\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|xxxxxxooooooooox   x|\n" +
                        "|     xoooooooooxxxxx|\n" +
                        "|     xoooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(4));
        assertEquals(shape_5,renderedShapesOnCanvas.get(4));

        String shape_6 =
                        "----------------------\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|xxxxxxooooooooox   x|\n" +
                        "|     xoooooooooxxxxx|\n" +
                        "|     xoooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(5));
        assertEquals(shape_6,renderedShapesOnCanvas.get(5));
    }

    @Test
    public void assert_Multiple_Command_Execution_With_Invalid_Line(){

        //given
        String canvasData = "Start \n C 20 4 \n L 1 2 6 2 \n L 6 3 61 4 \n R 16 1 20 3 \n B 10 3 o \n Q";

        scanner = generateScannerWithTestData(canvasData);

        //when
        drawingToolCommandController.executeCommandsFromScanner(scanner);

        //then
        List<String> renderedShapesOnCanvas = drawingToolCommandController.getRenderedShapesOnCanvas();

        assertNotNull(renderedShapesOnCanvas);
        assertEquals(6,renderedShapesOnCanvas.size());

        //expected Shape Data Assertion

        String shape_1 =
                "----------------------\n" +
                "|                    |\n" +
                "|                    |\n" +
                "|                    |\n" +
                "|                    |\n" +
                "______________________";

        assertNotNull(renderedShapesOnCanvas.get(0));
        assertEquals(shape_1,renderedShapesOnCanvas.get(0));


        String shape_2 =
                "----------------------\n" +
                "|                    |\n" +
                "|xxxxxx              |\n" +
                "|                    |\n" +
                "|                    |\n" +
                "______________________";

        assertNotNull(renderedShapesOnCanvas.get(1));
        assertEquals(shape_2,renderedShapesOnCanvas.get(1));


        String shape_3 = "Invalid line!";

        assertNotNull(renderedShapesOnCanvas.get(2));
        assertEquals(shape_3,renderedShapesOnCanvas.get(2));


        String shape_4 =
                                "----------------------\n" +
                                "|               xxxxx|\n" +
                                "|xxxxxx         x   x|\n" +
                                "|               xxxxx|\n" +
                                "|                    |\n" +
                                "______________________";

        assertNotNull(renderedShapesOnCanvas.get(3));
        assertEquals(shape_4,renderedShapesOnCanvas.get(3));


        String shape_5 =
                        "----------------------\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|xxxxxxooooooooox   x|\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(4));
        assertEquals(shape_5,renderedShapesOnCanvas.get(4));


        String shape_6 =
                        "----------------------\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|xxxxxxooooooooox   x|\n" +
                        "|oooooooooooooooxxxxx|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(5));
        assertEquals(shape_6,renderedShapesOnCanvas.get(5));
    }



    @Test
    public void assert_Multiple_Command_Execution_With_Multiple_Invalid_Shapes_On_Canvas(){

        //given
        String canvasData = "Start \n C 20 4 \n L 1 2 6 2 \n L 6 3 61 4 \n R 160 1 20 3 \n B 10 3 o \n Q";

        scanner = generateScannerWithTestData(canvasData);

        //when
        drawingToolCommandController.executeCommandsFromScanner(scanner);

        //then
        List<String> renderedShapesOnCanvas = drawingToolCommandController.getRenderedShapesOnCanvas();

        assertNotNull(renderedShapesOnCanvas);
        assertEquals(6,renderedShapesOnCanvas.size());

        //expected Shape Data Assertion

        String shape_1 =
                        "----------------------\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(0));
        assertEquals(shape_1,renderedShapesOnCanvas.get(0));


        String shape_2 =
                        "----------------------\n" +
                        "|                    |\n" +
                        "|xxxxxx              |\n" +
                        "|                    |\n" +
                        "|                    |\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(1));
        assertEquals(shape_2,renderedShapesOnCanvas.get(1));


        String shape_3 = "Invalid line!";

        assertNotNull(renderedShapesOnCanvas.get(2));
        assertEquals(shape_3,renderedShapesOnCanvas.get(2));


        String shape_4 = "Invalid rectangle.";

        assertNotNull(renderedShapesOnCanvas.get(3));
        assertEquals(shape_4,renderedShapesOnCanvas.get(3));


        String shape_5 =
                        "----------------------\n" +
                        "|oooooooooooooooooooo|\n" +
                        "|xxxxxxoooooooooooooo|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(4));
        assertEquals(shape_5,renderedShapesOnCanvas.get(4));


        String shape_6 =
                        "----------------------\n" +
                        "|oooooooooooooooooooo|\n" +
                        "|xxxxxxoooooooooooooo|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "|oooooooooooooooooooo|\n" +
                        "______________________";

        assertNotNull(renderedShapesOnCanvas.get(5));
        assertEquals(shape_6,renderedShapesOnCanvas.get(5));
    }
}

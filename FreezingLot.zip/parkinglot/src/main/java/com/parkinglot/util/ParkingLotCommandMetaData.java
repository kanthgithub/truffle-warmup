package com.parkinglot.util;

import com.parkinglot.service.ParkingLotOperationsService;

import java.lang.reflect.Method;

public class ParkingLotCommandMetaData {

    //All ReflectionUtils

    /**
     * @return Method
     */
    public static Method getCreateParkingLotMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("createParkingLot", String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - createParkingLot");

        } catch (Exception e) {
            System.out.println("invalid method access - createParkingLot");

        }

        return method;
    }

    /**
     * @return Method
     */
    public static Method getParkMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("park", String.class, String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - park");

        } catch (Exception e) {
            System.out.println("invalid method access - park");

        }

        return method;
    }

    /**
     * @return Method
     */
    public static Method getLeaveMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("leave", String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - leave");

        } catch (Exception e) {
            System.out.println("invalid method access - leave");

        }

        return method;
    }


    /**
     * @return Method
     */
    public static Method getquerySlotNumberFromRegistrationNumberMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("querySlotNumberFromRegistrationNumber", String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - querySlotNumberFromRegistrationNumber");

        } catch (Exception e) {
            System.out.println("invalid method access - querySlotNumberFromRegistrationNumber");
        }

        return method;
    }


    /**
     * @return Method
     */
    public static Method getextractAllRegistrationNumbersWithColorMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("extractAllRegistrationNumbersWithColor", String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - extractAllRegistrationNumbersWithColor");

        } catch (Exception e) {
            System.out.println("invalid method access - extractAllRegistrationNumbersWithColor");

        }

        return method;
    }


    /**
     * @return Method
     */
    public static Method getextractAllSlotNumbersWithColorMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("extractAllSlotNumbersWithColor", String.class);
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - extractAllSlotNumbersWithColor");

        } catch (Exception e) {
            System.out.println("invalid method access - extractAllSlotNumbersWithColor");

        }

        return method;
    }


    /**
     * @return Method
     */
    public static Method getqueryParkingSlotStatusReportMethod() {
        Method method = null;

        try {
            method = ParkingLotOperationsService.class.getMethod("queryParkingSlotStatusReport");
        } catch (NoSuchMethodException ex) {
            System.out.println("method doesnot exist - queryParkingSlotStatusReport");

        } catch (Exception e) {
            System.out.println("invalid method access - queryParkingSlotStatusReport");

        }

        return method;
    }


}

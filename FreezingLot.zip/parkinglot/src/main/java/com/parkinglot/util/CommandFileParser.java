package com.parkinglot.util;

import com.parkinglot.constants.ParkingCommand;
import com.parkinglot.model.ParkingCommandModel;

import java.io.*;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class CommandFileParser {

    /**
     * parse commands from file in to a collection of ParkingCommands to be executed
     *
     * @param filePath
     * @return List<ParkingCommandModel>
     */
    public List<ParkingCommandModel> parseCommandsFromFile(String filePath) {

        List<ParkingCommandModel> commands = new ArrayList<>();

        // Assuming input to be a valid file path.
        File inputFile = new File(filePath);
        try {
            BufferedReader br = new BufferedReader(new FileReader(inputFile));
            String line;
            try {
                while ((line = br.readLine()) != null) {

                    ParkingCommandModel parkingCommandModel = getParkingCommandModel(line);

                    commands.add(parkingCommandModel);
                }
            } catch (IOException ex) {
                System.out.println("Error in parsing input file.");
                ex.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            System.out.println("CommandFile not found in the path specified.");
            e.printStackTrace();
        }

        return commands;
    }

    /**
     * parse command arguments in to ParkingCommandModel
     *
     * @param line
     * @return ParkingCommandModel
     */
    public ParkingCommandModel getParkingCommandModel(String line) {
        String inputString = line.trim();
        String[] inputs = inputString.split(" ");

        ParkingCommandModel parkingCommandModel = new ParkingCommandModel();

        String commandString = inputs[0];
        ParkingCommand parkingCommand = ParkingCommand.getParkingCommandEnumFromCommandString(commandString);
        parkingCommandModel.setParkingCommand(parkingCommand);

        int argumentsCount = inputs.length;

        if(argumentsCount>1) {

            LinkedList<String> commandArguments = new LinkedList<>();

            for (int argumentIndex = 1; argumentIndex < argumentsCount; argumentIndex++){

                if(inputs[argumentIndex]!=null && inputs[argumentIndex].trim()!="") {
                    commandArguments.add(inputs[argumentIndex]);
                }
            }

            if(commandArguments!=null && commandArguments.size()>0) {
                parkingCommandModel.setCommandArguments(commandArguments);
            }
        }

        return parkingCommandModel;
    }
}

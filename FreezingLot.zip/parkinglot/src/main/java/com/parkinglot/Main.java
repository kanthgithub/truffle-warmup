package com.parkinglot;

import com.parkinglot.model.ParkingCommandModel;
import com.parkinglot.util.CommandFileParser;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class Main {

    public static void main(String... args) {

        ParkingLotCommandExecutor parkingLotCommandExecutor = initialize();

        CommandFileParser inputParser = new CommandFileParser();

        switch (args.length) {

            case 0:
                System.out.println("Please enter 'exit' to quit");
                System.out.println("Waiting for input...");

                // Interactive command-line-IO
                for (;;) {
                    try {
                        BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));
                        String inputString = bufferRead.readLine();
                        if (inputString.equalsIgnoreCase("exit")) {
                            break;
                        } else if ((inputString == null) || (inputString.isEmpty())) {
                            // Do nothing
                        } else {
                            ParkingCommandModel parkingCommandModel =
                                    inputParser.getParkingCommandModel(inputString.trim());
                            parkingLotCommandExecutor.executeCommand(parkingCommandModel);
                        }
                    } catch(IOException e) {
                        System.out.println("Oops! Error in reading the input from console.");
                        e.printStackTrace();
                    }
                }
                break;
            case 1:
                // File input/output
                List<ParkingCommandModel> parkingCommandModels =
                        inputParser.parseCommandsFromFile(args[0]);
                parkingLotCommandExecutor.executeCommands(parkingCommandModels);

                break;
            default:
                System.out.println("Invalid input. Usage: java -jar <jar_file_path> <input_file_path>");
        }
    }

    private static ParkingLotCommandExecutor initialize() {
        return new ParkingLotCommandExecutor();
    }


}

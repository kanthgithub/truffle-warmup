package com.parkinglot.model;

import com.parkinglot.constants.ParkingCommand;

import java.util.List;
import java.util.Objects;

public class ParkingCommandModel {

    private ParkingCommand parkingCommand;
    private List<String> commandArguments;

    public ParkingCommand getParkingCommand() {
        return parkingCommand;
    }

    public ParkingCommandModel setParkingCommand(ParkingCommand parkingCommand) {
        this.parkingCommand = parkingCommand;
        return this;
    }

    public List<String> getCommandArguments() {
        return commandArguments;
    }

    public ParkingCommandModel setCommandArguments(List<String> commandArguments) {
        this.commandArguments = commandArguments;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ParkingCommandModel)) return false;
        ParkingCommandModel that = (ParkingCommandModel) o;
        return getParkingCommand() == that.getParkingCommand() &&
                Objects.equals(getCommandArguments(), that.getCommandArguments());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getParkingCommand(), getCommandArguments());
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ParkingCommandModel{");
        sb.append("parkingCommand=").append(parkingCommand);
        sb.append(", commandArguments=").append(commandArguments);
        sb.append('}');
        return sb.toString();
    }
}

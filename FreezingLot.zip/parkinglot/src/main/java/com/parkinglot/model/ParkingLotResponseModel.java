package com.parkinglot.model;

import java.util.Objects;

public class ParkingLotResponseModel {

    private Integer slotNumber;

    private Car car;

    private Boolean isSuccessful;

    private String message;

    public Integer getSlotNumber() {
        return slotNumber;
    }

    public ParkingLotResponseModel setSlotNumber(Integer slotNumber) {
        this.slotNumber = slotNumber;
        return this;
    }

    public Car getCar() {
        return car;
    }

    public ParkingLotResponseModel setCar(Car car) {
        this.car = car;
        return this;
    }

    public Boolean getSuccessful() {
        return isSuccessful;
    }

    public ParkingLotResponseModel setSuccessful(Boolean successful) {
        isSuccessful = successful;
        return this;
    }

    public String getMessage() {
        return message;
    }

    public ParkingLotResponseModel setMessage(String message) {
        this.message = message;
        return this;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ParkingLotResponseModel)) return false;
        ParkingLotResponseModel that = (ParkingLotResponseModel) o;
        return Objects.equals(getSlotNumber(), that.getSlotNumber()) &&
                Objects.equals(getCar(), that.getCar()) &&
                Objects.equals(isSuccessful, that.isSuccessful) &&
                Objects.equals(getMessage(), that.getMessage());
    }

    @Override
    public int hashCode() {

        return Objects.hash(getSlotNumber(), getCar(), isSuccessful, getMessage());
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("ParkingLotResponseModel{");
        sb.append("slotNumber=").append(slotNumber);
        sb.append(", car=").append(car);
        sb.append(", isSuccessful=").append(isSuccessful);
        sb.append(", message='").append(message).append('\'');
        sb.append('}');
        return sb.toString();
    }
}

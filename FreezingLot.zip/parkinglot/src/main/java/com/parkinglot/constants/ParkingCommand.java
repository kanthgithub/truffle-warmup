package com.parkinglot.constants;

import com.parkinglot.util.ParkingLotCommandMetaData;

import java.lang.reflect.Method;

public enum ParkingCommand {

    CREATE_PARKING_LOT ("create_parking_lot", ParkingLotCommandMetaData.getCreateParkingLotMethod()),
    PARK ("park", ParkingLotCommandMetaData.getParkMethod()),
    LEAVE ("leave", ParkingLotCommandMetaData.getLeaveMethod()),
    STATUS ("status", ParkingLotCommandMetaData.getqueryParkingSlotStatusReportMethod()),
    REGISTRATION_NUMBERS_FOR_CARS_WITH_COLOUR ("registration_numbers_for_cars_with_colour", ParkingLotCommandMetaData.getextractAllRegistrationNumbersWithColorMethod()),
    SLOT_NUMBERS_FOR_CARS_WITH_COLOUR ("slot_numbers_for_cars_with_colour", ParkingLotCommandMetaData.getextractAllSlotNumbersWithColorMethod()),
    SLOT_NUMBER_FOR_REGISTRATION_NUMBER ("slot_number_for_registration_number", ParkingLotCommandMetaData.getquerySlotNumberFromRegistrationNumberMethod());

    private String commandString;
    private Method commandMethod;

    ParkingCommand(String commandString, Method commandMethod) {
        this.commandString = commandString;
        this.commandMethod = commandMethod;
    }

    public String getCommandString() {
        return commandString;
    }

    public Method getCommandMethod() {
        return commandMethod;
    }

    public static ParkingCommand getParkingCommandEnumFromCommandString(String commandString){

        ParkingCommand parkingCommand = null;

        for(ParkingCommand parkingCommandLocal : ParkingCommand.values()){
            if(commandString.equalsIgnoreCase(parkingCommandLocal.commandString)){
                parkingCommand = parkingCommandLocal;
                break;
            }
        }

        return parkingCommand;
    }


}

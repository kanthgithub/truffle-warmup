package com.parkinglot.repository;

import com.parkinglot.model.Car;

import java.util.concurrent.ConcurrentHashMap;

public class ParkingSlotStore {

    private Integer slotCountAtCreation;

    //map to store the parkedCars in the slots
    private ConcurrentHashMap<Integer,Car> parkedSlotMap;

    public ParkingSlotStore(ConcurrentHashMap<Integer, Car> parkedSlotMap) {
        this.parkedSlotMap = parkedSlotMap;
    }

    public ConcurrentHashMap<Integer, Car> getParkedSlotMap() {
        return parkedSlotMap;
    }

    public Integer getSlotCountAtCreation() {
        return slotCountAtCreation;
    }

    /**
     * create a brand new parkingLot with a slotCount limit
     * this should be called once as initiator method of main class
     *
     * @param slotCount
     * @return slots Count
     */
    public Integer createParkingLot(Integer slotCount){

        if (slotCountAtCreation == null) {
            synchronized (ParkingSlotStore.class) {
                if (slotCountAtCreation == null) {
                    slotCountAtCreation = slotCount;
                }
            }
        }

        return slotCountAtCreation;
    }

    public Boolean areSlotsAvailable(){
        return parkedSlotMap.size()<slotCountAtCreation;
    }

    /**
     * searches parkingSlotStore to get best available slot for parking
     *
     * @return bestAvailableSlot
     */
    public Integer getBestAvailableSlot(){

        Integer bestAvailableSlot = null;

        for(int index = 1;index<=slotCountAtCreation;index++){
           if(!parkedSlotMap.containsKey(index)) {
               bestAvailableSlot = index;
               break;
           }
        }

        return bestAvailableSlot;
    }
}

package com.parkinglot;

import com.parkinglot.model.Car;
import com.parkinglot.model.ParkingCommandModel;
import com.parkinglot.repository.ParkingSlotStore;
import com.parkinglot.service.ParkingLotAPIGatewayService;
import com.parkinglot.service.ParkingLotCommandService;
import com.parkinglot.service.ParkingLotOperationsService;
import com.parkinglot.service.ParkingLotQueryService;

import java.lang.reflect.InvocationTargetException;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ParkingLotCommandExecutor {

    ParkingLotOperationsService parkingLotOperationsService = null;

    public ParkingLotCommandExecutor() {
        initialize();
    }

    /**
     * initialize the services for ParkingLot Operations
     */
    private void initialize() {
        ParkingSlotStore parkingSlotStore = new ParkingSlotStore(new ConcurrentHashMap<Integer, Car>());

        ParkingLotQueryService parkingLotQueryService = new ParkingLotQueryService(parkingSlotStore);

        ParkingLotCommandService parkingLotCommandService = new ParkingLotCommandService(parkingSlotStore);

        ParkingLotAPIGatewayService parkingLotAPIGatewayService =
                new ParkingLotAPIGatewayService(parkingLotCommandService, parkingLotQueryService);

        parkingLotOperationsService =
                new ParkingLotOperationsService(parkingLotAPIGatewayService);
    }

    /**
     * execute a parkingLot Command
     *
     * @param parkingCommandModel
     */
    public String executeCommand(ParkingCommandModel parkingCommandModel) {

        List<String> parkingCommandArguments = parkingCommandModel.getCommandArguments();

        String responseString = null;

        try {
            if (parkingCommandArguments != null && !parkingCommandArguments.isEmpty()) {

                if (parkingCommandArguments.size() == 1) {
                    responseString = (String) parkingCommandModel.getParkingCommand().getCommandMethod().invoke(parkingLotOperationsService,
                            parkingCommandArguments.get(0));

                } else if (parkingCommandArguments.size() == 2) {
                    responseString = (String) parkingCommandModel.getParkingCommand().getCommandMethod().invoke(parkingLotOperationsService,
                            parkingCommandArguments.get(0), parkingCommandArguments.get(1));
                }

            } else {
                responseString = (String) parkingCommandModel.getParkingCommand().getCommandMethod().invoke(parkingLotOperationsService);
            }

        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }

        return responseString;
    }

    /**
     * execute a collection of commands
     *
     * @param parkingCommandModels
     */
    public List<String> executeCommands(List<ParkingCommandModel> parkingCommandModels) {

        List<String> responseStrings = new LinkedList<>();

        parkingCommandModels.stream().forEach(parkingCommandModel ->
        {
            String responseString = executeCommand(parkingCommandModel);
            responseStrings.add(responseString);
        });

        return responseStrings;
    }


}

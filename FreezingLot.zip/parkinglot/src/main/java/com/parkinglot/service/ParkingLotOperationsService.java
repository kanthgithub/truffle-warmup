package com.parkinglot.service;

import com.parkinglot.model.ParkingLotResponseModel;

import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ParkingLotOperationsService {

    private ParkingLotAPIGatewayService parkingLotAPIGatewayService;

    public ParkingLotOperationsService(ParkingLotAPIGatewayService parkingLotAPIGatewayService) {
        this.parkingLotAPIGatewayService = parkingLotAPIGatewayService;
    }

    public ParkingLotAPIGatewayService getParkingLotAPIGatewayService() {
        return parkingLotAPIGatewayService;
    }

    /**
     * extract slotNumber occupied by a vehicle with a specific registrationNumber
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @return slotNumber
     */
    public String querySlotNumberFromRegistrationNumber(String registrationNumber) {

        Integer slotNumber =
                parkingLotAPIGatewayService.querySlotNumberFromRegistrationNumber(registrationNumber);

        Integer slotCountAtCreation = parkingLotAPIGatewayService.getSlotCountAtCreation();

        StringBuffer responseStringBuffer = new StringBuffer();

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {

            responseStringBuffer.append("Sorry, parking lot is not created").append("\n");
        } else if (slotNumber != null) {
            responseStringBuffer.append(slotNumber.toString()).append("\n");
        } else {
            responseStringBuffer.append("Not found").append("\n");
        }

        printResponseStringBuffer(responseStringBuffer);


        return responseStringBuffer.toString();
    }

    /**
     * extract all slotNumbers occupied by vehicles of specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return response String (contains all slotNumbers with cars with specific color)
     */
    public String extractAllSlotNumbersWithColor(final String color) {

        List<Integer> slotNumbers =
                parkingLotAPIGatewayService.extractAllSlotNumbersWithColor(color);

        Integer slotCountAtCreation = parkingLotAPIGatewayService.getSlotCountAtCreation();

        StringBuffer responseStringBuffer = new StringBuffer();

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {

            responseStringBuffer.append("Sorry, parking lot is not created").append("\n");

        } else if (slotNumbers != null && !slotNumbers.isEmpty()) {
            responseStringBuffer.append("\n");
            responseStringBuffer.append(slotNumbers.stream().map((slotNumber) -> slotNumber.toString()).collect(Collectors.joining(", "))).append("\n");
        } else {
            responseStringBuffer.append("Not found").append("\n");
        }
        printResponseStringBuffer(responseStringBuffer);

        return responseStringBuffer.toString();
    }


    /**
     * extract RegistrationNumbers of all cars with a specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return registrationNumbers
     */
    public String extractAllRegistrationNumbersWithColor(String color) {

        List<String> registrationNumbers =
                parkingLotAPIGatewayService.extractAllRegistrationNumbersWithColor(color);

        Integer slotCountAtCreation = parkingLotAPIGatewayService.getSlotCountAtCreation();

        StringBuffer responseStringBuffer = new StringBuffer();

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {

            responseStringBuffer.append("Sorry, parking lot is not created").append("\n");

        } else if (registrationNumbers != null && !registrationNumbers.isEmpty()) {

            responseStringBuffer.append(registrationNumbers.stream().collect(Collectors.joining(", ")));

        } else {

            responseStringBuffer.append("Not found").append("\n");

        }

        printResponseStringBuffer(responseStringBuffer);

        return responseStringBuffer.toString();
    }


    /**
     * extract status of all parkingSlots
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @return parkingSlotStatusReport
     */
    public String queryParkingSlotStatusReport() {

        List<ParkingLotResponseModel> parkingLotResponseModels =
                parkingLotAPIGatewayService.queryParkingSlotStatusReport();

        Integer slotCountAtCreation = parkingLotAPIGatewayService.getSlotCountAtCreation();

        StringBuffer responseStringBuffer = new StringBuffer();

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {

            responseStringBuffer.append("Sorry, parking lot is not created").append("\n");

        } else if (parkingLotResponseModels != null && !parkingLotResponseModels.isEmpty()) {

            responseStringBuffer.append("Slot No.").append("\t").append("Registration No").append("\t").append("Color").append("\n");

            String reportString =
                    parkingLotResponseModels.stream().map(new Function<ParkingLotResponseModel, String>() {

                /**
                 * Applies this function to the given argument.
                 *
                 * @param parkingLotResponseModel the function argument
                 * @return the function result
                 */
                @Override
                public String apply(ParkingLotResponseModel parkingLotResponseModel) {
                    return new StringBuffer().append(parkingLotResponseModel.getSlotNumber()).append("\t")
                            .append(parkingLotResponseModel.getCar().getRegistrationNumber()).append("\t")
                            .append(parkingLotResponseModel.getCar().getColor()).append("\n").append("\n").toString();
                }
            }).collect(Collectors.joining(""));

            responseStringBuffer.append("\n");

            responseStringBuffer.append(reportString);


        } else {
            responseStringBuffer.append("Not found").append("\n");
        }

        responseStringBuffer.setLength(responseStringBuffer.length() - 1);

        printResponseStringBuffer(responseStringBuffer);

        return responseStringBuffer.toString();
    }


    /**
     * create a brand new parkingLot with a slotCount limit
     * this should be called once as initiator method of main class
     *
     * @param slotCount
     * @return responseString
     */
    public String createParkingLot(String slotCount) {

        StringBuffer responseStringBuffer = new StringBuffer();

        Integer slotCountForCreation = null;

        try {
            slotCountForCreation = Integer.parseInt(slotCount);
        }catch (Exception exc){
            responseStringBuffer.append("Invalid lot count").append(" slots").append("\n");
        }

        if(slotCountForCreation!=null) {
            Integer parkingLotsCreated = parkingLotAPIGatewayService.createParkingLot(slotCountForCreation);

            responseStringBuffer.append("Created parking lot with ").append(parkingLotsCreated.toString()).append(" slots").append("\n");
        }
        printResponseStringBuffer(responseStringBuffer);

        return responseStringBuffer.toString();
    }


    /**
     * park Vehicle
     * Car object is constructed by registrationNumber and color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @param color
     * @return responseString
     */
    public String park(String registrationNumber, String color) {

        StringBuffer responseStringBuffer = new StringBuffer();

        ParkingLotResponseModel parkingLotResponseModel =
                parkingLotAPIGatewayService.park(registrationNumber,color);

        responseStringBuffer.append(parkingLotResponseModel.getMessage()).append("\n");
        printResponseStringBuffer(responseStringBuffer);

        return responseStringBuffer.toString();
    }


    /**
     * leave a parking-slot
     * Slot is identified by slotNumber
     *
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param slotNumber
     * @return responseString
     */
    public String leave(String slotNumber) {

        StringBuffer responseStringBuffer = new StringBuffer();

        Integer slotNumberAsInteger = null;

        try {
            slotNumberAsInteger = Integer.parseInt(slotNumber);
        }catch (Exception exc){
        }

        ParkingLotResponseModel parkingLotResponseModel =
                parkingLotAPIGatewayService.leave(slotNumberAsInteger);

        responseStringBuffer.append(parkingLotResponseModel.getMessage()).append("\n");
        printResponseStringBuffer(responseStringBuffer);
        return responseStringBuffer.toString();
    }

    public void printResponseStringBuffer(StringBuffer responseStringBuffer){
        System.out.println(responseStringBuffer.toString());
    }


}

package com.parkinglot.service;

import com.parkinglot.model.ParkingLotResponseModel;

import java.util.List;

public class ParkingLotAPIGatewayService {

    private ParkingLotCommandService parkingLotCommandService;

    private ParkingLotQueryService parkingLotQueryService;

    public ParkingLotAPIGatewayService(ParkingLotCommandService parkingLotCommandService,
                                       ParkingLotQueryService parkingLotQueryService) {
        this.parkingLotCommandService = parkingLotCommandService;
        this.parkingLotQueryService = parkingLotQueryService;
    }

    /**
     * extract slotNumber occupied by a vehicle with a specific registrationNumber
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @return slotNumber
     */
    public Integer querySlotNumberFromRegistrationNumber(String registrationNumber) {

        return parkingLotQueryService.querySlotNumberFromRegistrationNumber(registrationNumber);
    }

    /**
     * extract all slotNumbers occupied by vehicles of specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return slotNumbers
     */
    public List<Integer> extractAllSlotNumbersWithColor(final String color) {

        return parkingLotQueryService.extractAllSlotNumbersWithColor(color);
    }


    /**
     * extract RegistrationNumbers of all cars with a specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return registrationNumbers
     */
    public List<String> extractAllRegistrationNumbersWithColor(String color) {

        return parkingLotQueryService.extractAllRegistrationNumbersWithColor(color);
    }


    /**
     * extract status of all parkingSlots
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @return parkingSlotStatusReport
     */
    public List<ParkingLotResponseModel> queryParkingSlotStatusReport() {

        return parkingLotQueryService.queryParkingSlotStatusReport();
    }


    /**
     * create a brand new parkingLot with a slotCount limit
     * this should be called once as initiator method of main class
     *
     * @param slotCount
     * @return Integer
     */
    public Integer createParkingLot(Integer slotCount){
        return parkingLotCommandService.createParkingLot(slotCount);
    }


    /**
     * park Vehicle
     * Car object is constructed by registrationNumber and color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @param color
     * @return parkingLotResponseModel
     */
    public ParkingLotResponseModel park(String registrationNumber, String color) {
        return parkingLotCommandService.park(registrationNumber,color);
    }



    /**
     * leave a parking-slot
     * Slot is identified by slotNumber
     *
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param slotNumber
     * @return parkingLotResponseModel
     */
    public ParkingLotResponseModel leave(Integer slotNumber) {

       return parkingLotCommandService.leave(slotNumber);
    }

    /**
     *
     * @return slots count captured during creation
     */
    public Integer getSlotCountAtCreation(){

        return parkingLotQueryService.getSlotCountAtCreation();

    }


}

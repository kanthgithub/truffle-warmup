package com.parkinglot.service;

import com.parkinglot.model.Car;
import com.parkinglot.model.ParkingLotResponseModel;
import com.parkinglot.repository.ParkingSlotStore;

import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

public class ParkingLotQueryService {

    private ParkingSlotStore parkingSlotStore;

    /**
     * @param parkingSlotStore
     */
    public ParkingLotQueryService(ParkingSlotStore parkingSlotStore) {
        this.parkingSlotStore = parkingSlotStore;
    }


    /**
     * extract slotNumber occupied by a vehicle with a specific registrationNumber
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @return slotNumber
     */
    public Integer querySlotNumberFromRegistrationNumber(String registrationNumber) {

        Optional<Integer> integer = parkingSlotStore.getParkedSlotMap().entrySet().stream()
                .filter((carEntry) -> carEntry.getValue().getRegistrationNumber().equals(registrationNumber))
                .findFirst().map(carEntry -> carEntry.getKey());

        Integer slotNumber = integer.isPresent() ? integer.get() : null;

        return slotNumber;
    }

    /**
     * extract all slotNumbers occupied by vehicles of specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return slotNumbers
     */
    public List<Integer> extractAllSlotNumbersWithColor(final String color) {

        List<Integer> slotNumbers = null;

        slotNumbers = parkingSlotStore.getParkedSlotMap().entrySet().stream()
                .filter((integerCarEntry) -> integerCarEntry.getValue().getColor().equals(color))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        return slotNumbers;
    }


    /**
     * extract RegistrationNumbers of all cars with a specific color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param color
     * @return registrationNumbers
     */
    public List<String> extractAllRegistrationNumbersWithColor(String color) {

        List<String> registrationNumbers = null;

        registrationNumbers = parkingSlotStore.getParkedSlotMap().entrySet().stream()
                .filter((carEntry) -> carEntry.getValue().getColor().equals(color))
                .map(Map.Entry::getValue).map(Car::getRegistrationNumber)
                .collect(Collectors.toCollection(LinkedList<String>::new));

        return registrationNumbers;
    }


    /**
     * extract status of all parkingSlots
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @return parkingSlotStatusReport
     */
    public List<ParkingLotResponseModel> queryParkingSlotStatusReport() {

        List<ParkingLotResponseModel> parkingSlotExtract =
        parkingSlotStore.getParkedSlotMap().entrySet().stream().map(new Function<Map.Entry<Integer, Car>, ParkingLotResponseModel>() {
            /**
             * Applies this function to the given argument.
             *
             * @param integerCarEntry the function argument
             * @return the function result
             */
            @Override
            public ParkingLotResponseModel apply(Map.Entry<Integer, Car> integerCarEntry) {
                return new ParkingLotResponseModel().setSlotNumber(integerCarEntry.getKey()).setCar(integerCarEntry.getValue());
            }
        }).collect(Collectors.toCollection(LinkedList<ParkingLotResponseModel>::new));

        return parkingSlotExtract;
    }

    /**
     * @return slots count captured during creation
     */
    public Integer getSlotCountAtCreation() {

        return parkingSlotStore.getSlotCountAtCreation();
    }
}

package com.parkinglot.service;

import com.parkinglot.model.Car;
import com.parkinglot.model.ParkingLotResponseModel;
import com.parkinglot.repository.ParkingSlotStore;

public class ParkingLotCommandService {

    private ParkingSlotStore parkingSlotStore;

    /**
     * @param parkingSlotStore
     */
    public ParkingLotCommandService(ParkingSlotStore parkingSlotStore) {
        this.parkingSlotStore = parkingSlotStore;
    }

    /**
     * create a brand new parkingLot with a slotCount limit
     * this should be called once as initiator method of main class
     *
     * @param slotCount
     * @return slots Count
     */
    public Integer createParkingLot(Integer slotCount){
        return parkingSlotStore.createParkingLot(slotCount);
    }


    /**
     * park Vehicle
     * Car object is constructed by registrationNumber and color
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param registrationNumber
     * @param color
     * @return responseString
     */
    public ParkingLotResponseModel park(String registrationNumber, String color) {

        Integer slotCountAtCreation = parkingSlotStore.getSlotCountAtCreation();

        String message = "";

        Boolean isSuccessful = Boolean.FALSE;

        ParkingLotResponseModel parkingLotResponseModel = new ParkingLotResponseModel();

        Car car = new Car(registrationNumber,color);

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {
            message = "Sorry, parking lot is not created";
        }else if(!parkingSlotStore.areSlotsAvailable()){
            message = "Sorry, parking lot is full";
        }else{
            Integer slotIndexForParking = parkingSlotStore.getBestAvailableSlot();

            parkingSlotStore.getParkedSlotMap().put(slotIndexForParking,car);

            message = String.format("Allocated slot number: %s",slotIndexForParking.toString());

            isSuccessful = Boolean.TRUE;

            parkingLotResponseModel.setCar(car).setSlotNumber(slotIndexForParking);
        }

        return parkingLotResponseModel.setMessage(message).setSuccessful(isSuccessful).setCar(car);
    }

    /**
     * leave a parking-slot
     * Slot is identified by slotNumber
     *
     * <p>
     * uses ParkingSlotStore Repository
     *
     * @param slotNumber
     * @return responseString
     */
    public ParkingLotResponseModel leave(Integer slotNumber) {

        Integer slotCountAtCreation = parkingSlotStore.getSlotCountAtCreation();

        String message = "";

        Boolean isSuccessful = Boolean.FALSE;

        Car car = null;

        if (slotCountAtCreation == null || slotCountAtCreation.equals(0)) {
            message = "Sorry, parking lot is not created";
        }else if(parkingSlotStore.getParkedSlotMap().isEmpty()){
            message = "Parking lot is empty";
        }else if(!parkingSlotStore.getParkedSlotMap().containsKey(slotNumber)){
            message = "Slot number " + slotNumber + " is already empty";
        }else{
            car = parkingSlotStore.getParkedSlotMap().remove(slotNumber);
            message = "Slot number " + slotNumber + " is free";
            isSuccessful = Boolean.TRUE;
        }

        return new ParkingLotResponseModel().setMessage(message).setSuccessful(isSuccessful)
                .setCar(car).setSlotNumber(slotNumber);
    }

}

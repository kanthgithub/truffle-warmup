package com.parkinglot.repository;

import com.parkinglot.model.Car;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.*;

public class ParkingSlotStoreTest {

    ParkingSlotStore parkingSlotStore = null;

    @Before
    public void initialize_Tests(){

        parkingSlotStore = new ParkingSlotStore(new ConcurrentHashMap<>());
    }

    @Test
    public void test_Create_Parking_Slot(){

        //given
        Integer parkingSlotsForCreation = 100;

        //when
        Integer parkingSlotsCreated =
                parkingSlotStore.createParkingLot(parkingSlotsForCreation);

        //then
        assertEquals(parkingSlotsForCreation,parkingSlotsCreated);
    }

    @Test
    public void test_Are_Parking_Slots_Available(){

        //given
        Integer parkingSlotsForCreation = 3;
        parkingSlotStore.createParkingLot(parkingSlotsForCreation);

        //scenario where parking-lots are not fully booked

        parkingSlotStore.getParkedSlotMap().put(1,new Car("1","White"));
        parkingSlotStore.getParkedSlotMap().put(2,new Car("2","Black"));

        //when
        Boolean parkingSlotsAvailableIndicator_Actual =  parkingSlotStore.areSlotsAvailable();

        //then
        assertTrue(parkingSlotsAvailableIndicator_Actual);

        //scenario where parking-lots are fully booked

        //given
        parkingSlotStore.getParkedSlotMap().put(3,new Car("3","Red"));

        //when
        parkingSlotsAvailableIndicator_Actual =  parkingSlotStore.areSlotsAvailable();

        //then
        assertFalse(parkingSlotsAvailableIndicator_Actual);

        //scenario where parking-lots are fully booked, and 1 car leaves space
        parkingSlotStore.getParkedSlotMap().remove(3);

        //when
        parkingSlotsAvailableIndicator_Actual =  parkingSlotStore.areSlotsAvailable();

        //then
        assertTrue(parkingSlotsAvailableIndicator_Actual);
    }

    @Test
    public void test_Get_Best_Available_Slot(){

        //given
        Integer parkingSlotsForCreation = 3;
        parkingSlotStore.createParkingLot(parkingSlotsForCreation);

        //scenario where parking-lots are not fully booked

        parkingSlotStore.getParkedSlotMap().put(1,new Car("1","White"));
        parkingSlotStore.getParkedSlotMap().put(2,new Car("2","Black"));

        //when
        Integer bestSlotAvailable_Actual =  parkingSlotStore.getBestAvailableSlot();

        //then
        assertNotNull(bestSlotAvailable_Actual);
        assertEquals(Integer.valueOf(3),bestSlotAvailable_Actual);
    }




}

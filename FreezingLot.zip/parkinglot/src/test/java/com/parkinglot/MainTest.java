package com.parkinglot;

import org.junit.Test;

public class MainTest {

    @Test
    public void test_Main_Application_For_Input_Commands_File() {
        String[] args = new String[1];
        args[0] = "file_inputs.txt";
        Main.main(args);
    }

}

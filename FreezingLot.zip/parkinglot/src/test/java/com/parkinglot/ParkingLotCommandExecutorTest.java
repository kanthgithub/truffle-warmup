package com.parkinglot;

import com.parkinglot.constants.ParkingCommand;
import com.parkinglot.model.ParkingCommandModel;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

public class ParkingLotCommandExecutorTest {

    ParkingLotCommandExecutor parkingLotCommandExecutor = null;

    @Before
    public void initTests() {
        parkingLotCommandExecutor = new ParkingLotCommandExecutor();
    }

    @Test
    public void test_Execute_ParkingLot_Command() {

        //given
        ParkingCommand parkingCommand = ParkingCommand.CREATE_PARKING_LOT;
        String lotCount = "6";

        String responseString_Expected = "Created parking lot with 6 slots" + "\n";

        ParkingCommandModel parkingCommandModel_Input =
                getAParkingCommandModelFromparams(parkingCommand, Arrays.asList(lotCount));

        //when
        String responseString_Actual =
                parkingLotCommandExecutor.executeCommand(parkingCommandModel_Input);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Execute_ParkingLot_Commands() {

        //given
        List<ParkingCommandModel> parkingCommandModels =
                prepare_Expected_Command_Model_Data();

        //when
        List<String> responseStrings_Actual =
                parkingLotCommandExecutor.executeCommands(parkingCommandModels);

        //then
        assertNotNull(responseStrings_Actual);
        assertEquals(15, responseStrings_Actual.size());

        List<String> responseStrings_Expected = prepareExpectedCommandResponseStrings();

        for (int index = 0; index < responseStrings_Actual.size(); index++) {
            assertTrue(responseStrings_Actual.get(index).trim()
                    .equals(responseStrings_Expected.get(index).trim()));
        }
    }


    private ParkingCommandModel getAParkingCommandModelFromparams(ParkingCommand parkingCommand, List<String> arguments) {
        return new ParkingCommandModel().setParkingCommand(parkingCommand)
                .setCommandArguments(arguments);
    }

    public List<ParkingCommandModel> prepare_Expected_Command_Model_Data() {

        List<ParkingCommandModel> parkingCommandModels = new LinkedList<>();

        //create_parking_lot 6
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.CREATE_PARKING_LOT, Arrays.asList("6")));

        //park KA-01-HH-1234 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-HH-1234", "White")));

        //park KA-01-HH-9999 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-HH-9999", "White")));

        //park KA-01-BB-0001 Black
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-BB-0001", "Black")));

        //park KA-01-HH-7777 Red
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-HH-7777", "Red")));

        //park KA-01-HH-2701 Blue
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-HH-2701", "Blue")));

        //park KA-01-HH-3141 Black
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-HH-3141", "Black")));

        //leave 4
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.LEAVE, Arrays.asList("4")));

        //status
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.STATUS, null));

        //park KA-01-P-333 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("KA-01-P-333", "White")));

        //park DL-12-AA-9999 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK, Arrays.asList("DL-12-AA-9999", "White")));

        //registration_numbers_for_cars_with_colour White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.REGISTRATION_NUMBERS_FOR_CARS_WITH_COLOUR, Arrays.asList("White")));

        //slot_numbers_for_cars_with_colour White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBERS_FOR_CARS_WITH_COLOUR, Arrays.asList("White")));

        //slot_number_for_registration_number KA-01-HH-3141
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBER_FOR_REGISTRATION_NUMBER, Arrays.asList("KA-01-HH-3141")));

        //slot_number_for_registration_number MH-04-AY-1111
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBER_FOR_REGISTRATION_NUMBER, Arrays.asList("MH-04-AY-1111")));

        return parkingCommandModels;
    }

    private List<String> prepareExpectedCommandResponseStrings() {

        List<String> responseStrings_Expected = new LinkedList<>();

        responseStrings_Expected.add("Created parking lot with 6 slots");

        responseStrings_Expected.add("Allocated slot number: 1");

        responseStrings_Expected.add("Allocated slot number: 2");

        responseStrings_Expected.add("Allocated slot number: 3");

        responseStrings_Expected.add("Allocated slot number: 4");

        responseStrings_Expected.add("Allocated slot number: 5");

        responseStrings_Expected.add("Allocated slot number: 6");

        responseStrings_Expected.add("Slot number 4 is free");

        responseStrings_Expected.add("Slot No.\tRegistration No\tColor\n\n1\tKA-01-HH-1234\tWhite\n\n" +
                "2\tKA-01-HH-9999\tWhite\n\n3\tKA-01-BB-0001\tBlack\n\n5\tKA-01-HH-2701\tBlue\n\n6\tKA-01-HH-3141\tBlack\n");

        responseStrings_Expected.add("Allocated slot number: 4");

        responseStrings_Expected.add("Sorry, parking lot is full");

        responseStrings_Expected.add("KA-01-HH-1234, KA-01-HH-9999, KA-01-P-333");

        responseStrings_Expected.add("1, 2, 4");

        responseStrings_Expected.add("6");

        responseStrings_Expected.add(" Not found");

        return responseStrings_Expected;
    }
}

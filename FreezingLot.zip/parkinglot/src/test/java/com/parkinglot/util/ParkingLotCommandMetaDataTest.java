package com.parkinglot.util;

import org.junit.Test;

import java.lang.reflect.Method;

import static org.junit.Assert.assertNotNull;

public class ParkingLotCommandMetaDataTest {

    @Test
    public void test_get_Create_ParkingLot_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getCreateParkingLotMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_Park_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getParkMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_Leave_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getLeaveMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_query_SlotNumber_From_RegistrationNumber_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getquerySlotNumberFromRegistrationNumberMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_extractAll_RegistrationNumbers_With_Color_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getextractAllRegistrationNumbersWithColorMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_extractAll_SlotNumbers_With_Color_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getextractAllSlotNumbersWithColorMethod();

        //then
        assertNotNull(method);
    }

    @Test
    public void test_get_query_ParkingSlot_Status_Report_Method(){

        //when
        Method method = ParkingLotCommandMetaData.getqueryParkingSlotStatusReportMethod();

        //then
        assertNotNull(method);
    }


}

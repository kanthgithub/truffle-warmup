package com.parkinglot.util;

import com.parkinglot.constants.ParkingCommand;
import com.parkinglot.model.ParkingCommandModel;
import org.junit.Before;
import org.junit.Test;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class CommandFileParserTest {

    CommandFileParser commandFileParser = null;

    @Before
    public void setupTests(){
        commandFileParser = new CommandFileParser();
    }

    @Test
    public void test_Parse_Command_File(){

        //given
        String testFileName = "file_inputs.txt";

        //when
        List<ParkingCommandModel> parkingCommandModels =
                commandFileParser.parseCommandsFromFile(testFileName);

        //then
        assertNotNull(parkingCommandModels);
        assertEquals(15,parkingCommandModels.size());
        assertEquals(prepare_Expected_Command_Model_Data(),parkingCommandModels);
    }

    @Test
    public void test_Parse_Line_To_ParkingCommandModel(){

        //given
        String commandLineString = "park DL-12-AA-9999 White";

        ParkingCommandModel parkingCommandModel_Expected =
                getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("DL-12-AA-9999","White"));

        //when
        ParkingCommandModel parkingCommandModel_Actual =
                commandFileParser.getParkingCommandModel(commandLineString);

        //then
        assertNotNull(parkingCommandModel_Actual);
        assertEquals(parkingCommandModel_Expected,parkingCommandModel_Actual);
    }



    public List<ParkingCommandModel> prepare_Expected_Command_Model_Data(){

        List<ParkingCommandModel> parkingCommandModels = new LinkedList<>();

        //create_parking_lot 6
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.CREATE_PARKING_LOT,Arrays.asList("6")));

        //park KA-01-HH-1234 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-HH-1234","White")));

        //park KA-01-HH-9999 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-HH-9999","White")));

        //park KA-01-BB-0001 Black
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-BB-0001","Black")));

        //park KA-01-HH-7777 Red
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-HH-7777","Red")));

       //park KA-01-HH-2701 Blue
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-HH-2701","Blue")));

        //park KA-01-HH-3141 Black
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-HH-3141","Black")));

        //leave 4
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.LEAVE,Arrays.asList("4")));

        //status
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.STATUS,null));

        //park KA-01-P-333 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("KA-01-P-333","White")));

        //park DL-12-AA-9999 White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.PARK,Arrays.asList("DL-12-AA-9999","White")));

        //registration_numbers_for_cars_with_colour White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.REGISTRATION_NUMBERS_FOR_CARS_WITH_COLOUR,Arrays.asList("White")));

        //slot_numbers_for_cars_with_colour White
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBERS_FOR_CARS_WITH_COLOUR,Arrays.asList("White")));

        //slot_number_for_registration_number KA-01-HH-3141
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBER_FOR_REGISTRATION_NUMBER,Arrays.asList("KA-01-HH-3141")));

        //slot_number_for_registration_number MH-04-AY-1111
        parkingCommandModels.add(getAParkingCommandModelFromparams(ParkingCommand.SLOT_NUMBER_FOR_REGISTRATION_NUMBER,Arrays.asList("MH-04-AY-1111")));

        return parkingCommandModels;
    }

    private ParkingCommandModel getAParkingCommandModelFromparams(ParkingCommand parkingCommand,List<String> arguments)
    {
        return new ParkingCommandModel().setParkingCommand(parkingCommand)
                .setCommandArguments(arguments);
    }
}
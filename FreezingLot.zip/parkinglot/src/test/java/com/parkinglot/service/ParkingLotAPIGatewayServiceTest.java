package com.parkinglot.service;

import com.parkinglot.model.Car;
import com.parkinglot.model.ParkingLotResponseModel;
import com.parkinglot.repository.ParkingSlotStore;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.*;

public class ParkingLotAPIGatewayServiceTest {

    //System Under Test
    ParkingLotAPIGatewayService parkingLotAPIGatewayService = null;


    ParkingLotQueryService parkingLotQueryService = null;

    ParkingLotCommandService parkingLotCommandService = null;

    Integer slotsForCreation = 100;

    @Before
    public void initialize_Tests(){

        ParkingSlotStore parkingSlotStore =
                new ParkingSlotStore(new ConcurrentHashMap<>());

        parkingLotQueryService
                = new ParkingLotQueryService(parkingSlotStore);

        parkingLotCommandService
                = new ParkingLotCommandService(parkingSlotStore);

        parkingLotAPIGatewayService =
                new ParkingLotAPIGatewayService(parkingLotCommandService,parkingLotQueryService);
    }


    @Test
    public void test_Successful_Query_SlotNumber_From_RegistrationNumber(){

        //given

        parkingLotCommandService.createParkingLot(slotsForCreation);

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotAPIGatewayService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotAPIGatewayService.park(registrationNumber2,color2);

        //when
        Integer slotNumber_Actual =
                parkingLotAPIGatewayService.querySlotNumberFromRegistrationNumber(registrationNumber1);

        //then
        assertNotNull(slotNumber_Actual);
        assertEquals(parkingLotResponseModel_Park1.getSlotNumber(),slotNumber_Actual);
    }

    @Test
    public void test_Failed_Query_SlotNumber_From_RegistrationNumber(){

        //given

        parkingLotCommandService.createParkingLot(slotsForCreation);

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotAPIGatewayService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        //when
        Integer slotNumber_Actual =
                parkingLotAPIGatewayService.querySlotNumberFromRegistrationNumber(registrationNumber2);

        //then
        assertNull(slotNumber_Actual);
    }

    @Test
    public void test_Successful_Extraction_Of_SlotNumbers_With_Identical_Colors(){

        //given
        parkingLotCommandService.createParkingLot(slotsForCreation);


        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotAPIGatewayService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotAPIGatewayService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotAPIGatewayService.park(registrationNumber3,color3);

        String colorForExtraction = "Red";

        //when
        List<Integer> slotNumbers_Actual =
                parkingLotAPIGatewayService.extractAllSlotNumbersWithColor(colorForExtraction);

        //then
        assertNotNull(slotNumbers_Actual);
        assertTrue(slotNumbers_Actual.size()==2);
        assertTrue(slotNumbers_Actual.contains(parkingLotResponseModel_Park2.getSlotNumber()));
        assertTrue(slotNumbers_Actual.contains(parkingLotResponseModel_Park3.getSlotNumber()));
    }

    @Test
    public void test_Successful_Extraction_Of_RegistrationNumbers_With_Identical_Colors(){

        //given
        parkingLotCommandService.createParkingLot(slotsForCreation);


        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotAPIGatewayService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotAPIGatewayService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotAPIGatewayService.park(registrationNumber3,color3);

        String colorForExtraction = "Red";

        //when
        List<String> registrationNumbers_Actual =
                parkingLotAPIGatewayService.extractAllRegistrationNumbersWithColor(colorForExtraction);

        //then
        assertNotNull(registrationNumbers_Actual);
        assertTrue(registrationNumbers_Actual.size()==2);
        assertTrue(registrationNumbers_Actual.contains(registrationNumber2));
        assertTrue(registrationNumbers_Actual.contains(registrationNumber3));
    }

    @Test
    public void test_query_ParkingSlot_StatusReport(){

        //given

        parkingLotCommandService.createParkingLot(slotsForCreation);


        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotAPIGatewayService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotAPIGatewayService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotAPIGatewayService.park(registrationNumber3,color3);


        //when
        List<ParkingLotResponseModel> parkingLotStatusReport_Actual =
                parkingLotAPIGatewayService.queryParkingSlotStatusReport();

        //then
        assertNotNull(parkingLotStatusReport_Actual);
        assertTrue(parkingLotStatusReport_Actual.size()==3);
    }

    @Test
    public void test_Slot_Count_At_Creation(){

        parkingLotCommandService.createParkingLot(slotsForCreation);

        //when
        Integer slotCountAtCreation_Actual =
                parkingLotAPIGatewayService.getSlotCountAtCreation();

        //then
        assertNotNull(slotCountAtCreation_Actual);
        assertEquals(slotsForCreation,slotCountAtCreation_Actual);
    }




    @Test
    public void test_create_ParkingLot(){

        //given
        Integer parkingSlotsForCreation = 100;

        //when
        Integer parkingSlotsCreated =
                parkingLotAPIGatewayService.createParkingLot(parkingSlotsForCreation);

        //then
        assertEquals(parkingSlotsForCreation,parkingSlotsCreated);
    }

    @Test
    public void test_Successful_Car_Parking(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(100);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.TRUE).setMessage("Allocated slot number: 1")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(Integer.valueOf(1));

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Car_Parking(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(0);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is not created")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(null);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Car_Parking_Slot_NotAvailable_Scenario(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(1);
        parkingLotCommandService.park("TEST-1121","Red");

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is full")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(null);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_Successful_Slot_Release(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";
        Integer slotNumber = Integer.valueOf(1);

        parkingLotCommandService.createParkingLot(100);
        parkingLotCommandService.park(registrationNumber,color);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.TRUE).setMessage("Slot number 1 is free")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(Integer.valueOf(1));

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release(){

        //given
        Integer slotNumber = Integer.valueOf(1);

        parkingLotCommandService.createParkingLot(0);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is not created")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release_Empty_Lot_Scenario(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(100);

        ParkingLotResponseModel parkingLotResponseModel_Park =
                parkingLotCommandService.park(registrationNumber,color);

        Integer slotNumber = parkingLotResponseModel_Park.getSlotNumber();

        parkingLotCommandService.leave(slotNumber);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Parking lot is empty")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release_Duplicate_Release_Attempt_Scenario(){

        //given

        parkingLotCommandService.createParkingLot(100);

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);

        Integer slotNumber = parkingLotResponseModel_Park2.getSlotNumber();

        parkingLotCommandService.leave(slotNumber);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Slot number " + slotNumber + " is already empty")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotAPIGatewayService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

}

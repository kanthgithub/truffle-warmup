package com.parkinglot.service;

import com.parkinglot.model.Car;
import com.parkinglot.model.ParkingLotResponseModel;
import com.parkinglot.repository.ParkingSlotStore;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ParkingLotCommandServiceTest {

    ParkingLotCommandService parkingLotCommandService = null;

    @Before
    public void initialize_Tests(){

        ParkingSlotStore parkingSlotStore =
                new ParkingSlotStore(new ConcurrentHashMap<>());
        parkingLotCommandService = new ParkingLotCommandService(parkingSlotStore);
    }

    @Test
    public void test_create_ParkingLot(){

        //given
        Integer parkingSlotsForCreation = 100;

        //when
        Integer parkingSlotsCreated =
                parkingLotCommandService.createParkingLot(parkingSlotsForCreation);

        //then
        assertEquals(parkingSlotsForCreation,parkingSlotsCreated);
    }

    @Test
    public void test_Successful_Car_Parking(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(100);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.TRUE).setMessage("Allocated slot number: 1")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(Integer.valueOf(1));

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Car_Parking(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(0);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is not created")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(null);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Car_Parking_Slot_NotAvailable_Scenario(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(1);
        parkingLotCommandService.park("TEST-1121","Red");

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is full")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(null);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.park(registrationNumber,color);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_Successful_Slot_Release(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";
        Integer slotNumber = Integer.valueOf(1);

        parkingLotCommandService.createParkingLot(100);
        parkingLotCommandService.park(registrationNumber,color);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.TRUE).setMessage("Slot number 1 is free")
                        .setCar(new Car().setRegistrationNumber(registrationNumber).setColor(color))
                        .setSlotNumber(Integer.valueOf(1));

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release(){

        //given
        Integer slotNumber = Integer.valueOf(1);

        parkingLotCommandService.createParkingLot(0);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Sorry, parking lot is not created")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release_Empty_Lot_Scenario(){

        //given
        String registrationNumber = "SG-1121-YT";
        String color = "Black";

        parkingLotCommandService.createParkingLot(100);

        ParkingLotResponseModel parkingLotResponseModel_Park =
                parkingLotCommandService.park(registrationNumber,color);

        Integer slotNumber = parkingLotResponseModel_Park.getSlotNumber();

        parkingLotCommandService.leave(slotNumber);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Parking lot is empty")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }

    @Test
    public void test_UnSuccessful_Slot_Release_Duplicate_Release_Attempt_Scenario(){

        //given

        parkingLotCommandService.createParkingLot(100);

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);

        Integer slotNumber = parkingLotResponseModel_Park2.getSlotNumber();

        parkingLotCommandService.leave(slotNumber);

        ParkingLotResponseModel parkingLotResponseModel_Expected =
                new ParkingLotResponseModel().setSuccessful(Boolean.FALSE)
                        .setMessage("Slot number " + slotNumber + " is already empty")
                        .setSlotNumber(slotNumber);

        //when
        ParkingLotResponseModel parkingLotResponseModel_Actual =
                parkingLotCommandService.leave(slotNumber);

        //then
        assertNotNull(parkingLotResponseModel_Actual);
        assertEquals(parkingLotResponseModel_Expected,parkingLotResponseModel_Actual);
    }
}

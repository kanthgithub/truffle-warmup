package com.parkinglot.service;

import com.parkinglot.model.ParkingLotResponseModel;
import com.parkinglot.repository.ParkingSlotStore;
import org.junit.Before;
import org.junit.Test;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.*;

public class ParkingLotQueryServiceTest {

    //System Under Test
    ParkingLotQueryService parkingLotQueryService = null;

    //Helper to park and leave cars
    ParkingLotCommandService parkingLotCommandService = null;

    Integer slotsForCreation = 100;

    @Before
    public void initialize_Tests(){

        ParkingSlotStore parkingSlotStore =
                new ParkingSlotStore(new ConcurrentHashMap<>());
        parkingLotQueryService = new ParkingLotQueryService(parkingSlotStore);

        parkingLotCommandService = new ParkingLotCommandService(parkingSlotStore);

        parkingLotCommandService.createParkingLot(slotsForCreation);
    }

    @Test
    public void test_Successful_Query_SlotNumber_From_RegistrationNumber(){

        //given

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);

        //when
        Integer slotNumber_Actual =
                parkingLotQueryService.querySlotNumberFromRegistrationNumber(registrationNumber1);

        //then
        assertNotNull(slotNumber_Actual);
        assertEquals(parkingLotResponseModel_Park1.getSlotNumber(),slotNumber_Actual);
    }

    @Test
    public void test_Failed_Query_SlotNumber_From_RegistrationNumber(){

        //given

        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        //when
        Integer slotNumber_Actual =
                parkingLotQueryService.querySlotNumberFromRegistrationNumber(registrationNumber2);

        //then
        assertNull(slotNumber_Actual);
    }

    @Test
    public void test_Successful_Extraction_Of_SlotNumbers_With_Identical_Colors(){

        //given
        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotCommandService.park(registrationNumber3,color3);

        String colorForExtraction = "Red";

        //when
        List<Integer> slotNumbers_Actual =
                parkingLotQueryService.extractAllSlotNumbersWithColor(colorForExtraction);

        //then
        assertNotNull(slotNumbers_Actual);
        assertTrue(slotNumbers_Actual.size()==2);
        assertTrue(slotNumbers_Actual.contains(parkingLotResponseModel_Park2.getSlotNumber()));
        assertTrue(slotNumbers_Actual.contains(parkingLotResponseModel_Park3.getSlotNumber()));
    }

    @Test
    public void test_Successful_Extraction_Of_RegistrationNumbers_With_Identical_Colors(){

        //given
        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotCommandService.park(registrationNumber3,color3);

        String colorForExtraction = "Red";

        //when
        List<String> registrationNumbers_Actual =
                parkingLotQueryService.extractAllRegistrationNumbersWithColor(colorForExtraction);

        //then
        assertNotNull(registrationNumbers_Actual);
        assertTrue(registrationNumbers_Actual.size()==2);
        assertTrue(registrationNumbers_Actual.contains(registrationNumber2));
        assertTrue(registrationNumbers_Actual.contains(registrationNumber3));
    }

    @Test
    public void test_query_ParkingSlot_StatusReport(){

        //given
        String registrationNumber1 = "SG-1121-YT";
        String color1 = "Black";

        ParkingLotResponseModel parkingLotResponseModel_Park1 =
                parkingLotCommandService.park(registrationNumber1,color1);

        String registrationNumber2= "SG-9999-YT";
        String color2 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park2 =
                parkingLotCommandService.park(registrationNumber2,color2);


        String registrationNumber3= "SG-5543-YT";
        String color3 = "Red";

        ParkingLotResponseModel parkingLotResponseModel_Park3 =
                parkingLotCommandService.park(registrationNumber3,color3);


        //when
        List<ParkingLotResponseModel> parkingLotStatusReport_Actual =
                parkingLotQueryService.queryParkingSlotStatusReport();

        //then
        assertNotNull(parkingLotStatusReport_Actual);
        assertTrue(parkingLotStatusReport_Actual.size()==3);
    }

    @Test
    public void test_Slot_Count_At_Creation(){

        //when
        Integer slotCountAtCreation_Actual =
                parkingLotQueryService.getSlotCountAtCreation();

        //then
        assertNotNull(slotCountAtCreation_Actual);
        assertEquals(slotsForCreation,slotCountAtCreation_Actual);
    }



}

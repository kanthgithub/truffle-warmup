package com.parkinglot.service;

import com.parkinglot.repository.ParkingSlotStore;
import org.junit.Before;
import org.junit.Test;

import java.util.concurrent.ConcurrentHashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class ParkingLotOperationsServiceTest {


    //System Under Test
    ParkingLotOperationsService parkingLotOperationsService = null;

    //dependents
    ParkingLotAPIGatewayService parkingLotAPIGatewayService = null;

    ParkingLotQueryService parkingLotQueryService = null;

    ParkingLotCommandService parkingLotCommandService = null;

    Integer slotsForCreation = 100;

    @Before
    public void initialize_Tests(){

        ParkingSlotStore parkingSlotStore =
                new ParkingSlotStore(new ConcurrentHashMap<>());

        parkingLotQueryService
                = new ParkingLotQueryService(parkingSlotStore);

        parkingLotCommandService
                = new ParkingLotCommandService(parkingSlotStore);

        parkingLotAPIGatewayService =
                new ParkingLotAPIGatewayService(parkingLotCommandService,parkingLotQueryService);

        parkingLotOperationsService = new ParkingLotOperationsService(parkingLotAPIGatewayService);
    }


    @Test
    public void test_Create_Parking_Lot(){

        //given
        String lotCount = "6";

        String responseString_Expected = "Created parking lot with 6 slots" + "\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.createParkingLot(lotCount);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Create_Parking_Lot_InvalidLotCount(){

        //given
        String lotCount = "InvalidNumber";

        String responseString_Expected = "Invalid lot count slots" + "\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.createParkingLot(lotCount);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Park_A_Car(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String responseString_Expected = "Allocated slot number: 1" + "\n";

        String registrationNumber1 = "SG-112-IU";
        String color = "Red";

        //when
        String responseString_Actual =
                parkingLotOperationsService.park(registrationNumber1,color);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Park_A_Car_Failure(){

        //given
        String lotCount = "1";
        parkingLotOperationsService.createParkingLot(lotCount);

        String responseString_Expected = "Sorry, parking lot is full" + "\n";

        String registrationNumber1 = "SG-112-IU";
        String color1 = "Red";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "MY-112-IU";
        String color2 = "Black";

        //when
        String responseString_Actual =
                parkingLotOperationsService.park(registrationNumber2,color2);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Leave_A_Car_From_Lot(){

        //given
        String lotCount = "3";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "SG-112-IU";
        String color1 = "Red";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "MY-112-IU";
        String color2 = "Black";

        parkingLotOperationsService.park(registrationNumber2,color2);

        String responseString_Expected = "Slot number 2 is free" + "\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.leave("2");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Leave_A_Car_From_Lot_UnSuccessful_Scenario(){

        //given
        String lotCount = "3";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "SG-112-IU";
        String color1 = "Red";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "MY-112-IU";
        String color2 = "Black";

        parkingLotOperationsService.park(registrationNumber2,color2);

        String responseString_Expected = "Slot number 3 is already empty" + "\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.leave("3");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Extract_Status_Report(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);

        String registrationNumber4 = "KA-01-HH-2701";
        String color4 = "Blue";

        parkingLotOperationsService.park(registrationNumber4,color4);


        String registrationNumber5 = "KA-01-HH-3141";
        String color5 = "Black";

        parkingLotOperationsService.park(registrationNumber5,color5);


        String responseString_Expected = "Slot No.\tRegistration No\tColor\n\n1\tKA-01-HH-1234\tWhite\n\n" +
                "2\tKA-01-HH-9999\tWhite\n\n3\tKA-01-BB-0001\tBlack\n\n4\tKA-01-HH-2701\tBlue\n\n5\tKA-01-HH-3141\tBlack\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.queryParkingSlotStatusReport();

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_Query_SlotNumber_From_Registration_Number(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);

        String registrationNumber4 = "KA-01-HH-2701";
        String color4 = "Blue";

        parkingLotOperationsService.park(registrationNumber4,color4);


        String registrationNumber5 = "KA-01-HH-3141";
        String color5 = "Black";

        parkingLotOperationsService.park(registrationNumber5,color5);


        String responseString_Expected = "3\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.querySlotNumberFromRegistrationNumber(registrationNumber3);

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_extract_All_SlotNumbers_With_Color(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);


        String responseString_Expected = "\n1, 2\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.extractAllSlotNumbersWithColor("White");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_extract_All_SlotNumbers_With_Color_Failure_Scenario(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);


        String responseString_Expected = "Not found\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.extractAllSlotNumbersWithColor("Red");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_extract_All_RegistrationNumbers_With_Color(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);


        String responseString_Expected = "KA-01-HH-1234, KA-01-HH-9999";

        //when
        String responseString_Actual =
                parkingLotOperationsService.extractAllRegistrationNumbersWithColor("White");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

    @Test
    public void test_extract_All_RegistrationNumbers_With_Color_Failure_Scenario(){

        //given
        String lotCount = "6";
        parkingLotOperationsService.createParkingLot(lotCount);

        String registrationNumber1 = "KA-01-HH-1234";
        String color1 = "White";

        parkingLotOperationsService.park(registrationNumber1,color1);

        String registrationNumber2 = "KA-01-HH-9999";
        String color2 = "White";

        parkingLotOperationsService.park(registrationNumber2,color2);


        String registrationNumber3 = "KA-01-BB-0001";
        String color3 = "Black";

        parkingLotOperationsService.park(registrationNumber3,color3);


        String responseString_Expected = "Not found\n";

        //when
        String responseString_Actual =
                parkingLotOperationsService.extractAllRegistrationNumbersWithColor("Red");

        //then
        assertNotNull(responseString_Expected);
        assertEquals(responseString_Expected, responseString_Actual);
    }

}

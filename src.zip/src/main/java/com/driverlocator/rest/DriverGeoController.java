package com.driverlocator.rest;

import com.driverlocator.model.DriverGeoLoggingResponseModel;
import com.driverlocator.model.DriverGeoModel;
import com.driverlocator.service.DriverGeoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DriverGeoController {

    Logger log = LoggerFactory.getLogger(DriverGeoController.class);

    @Autowired
    DriverGeoService driverGeoService;

    @RequestMapping(value = "/drivers/{id}/location" , method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity recordDriverGeoLocation(@PathVariable Long id,
                                                  @RequestBody DriverGeoModel driverGeoModel){

        log.info("recording location: {}",driverGeoModel);

        DriverGeoLoggingResponseModel driverGeoLoggingResponseModel =
                driverGeoService.validateGeoLogEvent(driverGeoModel);

        HttpStatus responseStatus = null;

        List<String> messages = null;

        DriverGeoModel driverGeoModel_Saved = null;

        if(!driverGeoLoggingResponseModel.getIsValid()){
            messages = driverGeoLoggingResponseModel.getMessage();
            responseStatus = HttpStatus.UNPROCESSABLE_ENTITY;
        }else{
            driverGeoModel_Saved = driverGeoService.insertDriverLocationLogEvent(driverGeoModel);
            responseStatus = HttpStatus.OK;
        }

        return !driverGeoLoggingResponseModel.getIsValid() ? new ResponseEntity(messages,responseStatus)
                : ResponseEntity.ok(driverGeoModel_Saved);
    }


}

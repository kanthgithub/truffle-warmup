package com.driverlocator.service;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverLocatorModel;
import com.driverlocator.model.DriverLocatorQueryParameters;
import com.driverlocator.model.DriverLocatorRequestModel;
import com.driverlocator.model.DriverLocatorResponseModel;
import com.driverlocator.repository.DriverGeoRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class DriverFinderServiceImpl implements DriverFinderService {

    @Autowired
    DriverGeoRepository driverGeoRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public DriverLocatorResponseModel findMyNearestGoJeks(DriverLocatorRequestModel driverLocatorRequestModel){

        List<String> messages = validateLocatorRequestParameters(driverLocatorRequestModel);

        Boolean isValid = !messages.isEmpty() ? Boolean.FALSE : Boolean.TRUE;

        List<DriverLocatorModel> driverLocatorModels = isValid ? findDrivers(driverLocatorRequestModel) : null;

        return DriverLocatorResponseModel.builder().nearestDrivers(driverLocatorModels).isValid(isValid).message(messages).build();
    }

    public List<String> validateLocatorRequestParameters(DriverLocatorRequestModel driverLocatorRequestModel) {

        Double latitude_Parameter = driverLocatorRequestModel.getLatitude();

        Double longitude_Parameter = driverLocatorRequestModel.getLongitude();

        Long radius_Parameter = driverLocatorRequestModel.getRadius();

        List<String> messages = new ArrayList<>();

        if(90 < latitude_Parameter || latitude_Parameter < -90){
            messages.add("Latitude should be between +/- 90");
        }

        if(180 < longitude_Parameter || longitude_Parameter < -180){
            messages.add("Longitude should be between +/- 180");
        }

        if(radius_Parameter < 0 || radius_Parameter >10000){
            messages.add("Unacceptable radius value");
        }
        return messages;
    }

    @Override
    public List<DriverLocatorModel> findDrivers(DriverLocatorRequestModel driverLocatorRequestModel) {

        Long radius = driverLocatorRequestModel.getRadius();

        Double latitudeParam_Min = driverLocatorRequestModel.getLatitude() - radius;
        Double latitudeParam_Max = driverLocatorRequestModel.getLatitude() + radius;

        Double longitudeParam_Min = driverLocatorRequestModel.getLongitude() - radius;
        Double longitudeParam_Max = driverLocatorRequestModel.getLongitude() + radius;

        DriverLocatorQueryParameters driverLocatorQueryParameters =
                DriverLocatorQueryParameters.builder().latitudeParam_Min(latitudeParam_Min)
                                                        .latitudeParam_Max(latitudeParam_Max)
                                                        .longitudeParam_Min(longitudeParam_Min)
                                                        .longitudeParam_Max(longitudeParam_Max)
                        .radius(radius).build();

        List<DriverGeo> driverGeos = driverGeoRepository.findNearestDrivers(driverLocatorQueryParameters);


        //further filter to check on radius, filtered entity's latitude and longitude, distance computed

        /**
         * double x = Math.abs(latitude - lat);
         double y = Math.abs(longitude - longi);
         double dist = x*x + y*y;
         if(radius*radius >= dist)
         */

        return driverGeos.stream().map(new Function<DriverGeo, DriverLocatorModel>() {
            /**
             * Applies this function to the given argument.
             *
             * @param driverGeoArgument the function argument
             * @return the function result
             */
            @Override
            public DriverLocatorModel apply(DriverGeo driverGeoArgument) {
                return  modelMapper.map(driverGeoArgument, DriverLocatorModel.class );
            }
        }).collect(Collectors.toList());
    }

}

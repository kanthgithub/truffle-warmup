package com.driverlocator.model;

import lombok.*;

@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class DriverLocatorModel {

    private Long id;

    private Double longitude;

    private Double latitude;

    private Double accuracy;

}

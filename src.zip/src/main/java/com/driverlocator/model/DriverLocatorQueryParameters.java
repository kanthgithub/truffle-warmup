package com.driverlocator.model;

import lombok.*;

@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class DriverLocatorQueryParameters {

    Long radius ;
    Long limit;
    Double latitudeParam_Min ;
    Double latitudeParam_Max ;
    Double longitudeParam_Min ;
    Double longitudeParam_Max ;
}

package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeo;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface DriverGeoRepository extends ReactiveMongoRepository<DriverGeo, String>,DriverGeoRepositoryCustom {


}


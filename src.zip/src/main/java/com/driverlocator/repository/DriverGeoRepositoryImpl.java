package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverLocatorQueryParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Repository
public class DriverGeoRepositoryImpl implements DriverGeoRepositoryCustom {

    @Autowired
    private ReactiveMongoTemplate reactiveMongoTemplate;

    /**
     * @param userId
     * @return DriverGeo
     */
    @Override
    public DriverGeo checkDriverEntry(Long userId) {

        Query query = query(where("userId").is(userId));

        return reactiveMongoTemplate.findOne(query,DriverGeo.class ).block();
    }

    /**
     * @param driverLocatorQueryParameters
     * @return List<DriverGeo>
     */
    @Override
    public List<DriverGeo> findNearestDrivers(DriverLocatorQueryParameters driverLocatorQueryParameters) {

        List<DriverGeo> nearest_DriverGeos = null;

        //TODO
        Double latitudeMin = driverLocatorQueryParameters.getLatitudeParam_Min();
        Double latitudeMax = driverLocatorQueryParameters.getLatitudeParam_Max();
        Double longitudeMin = driverLocatorQueryParameters.getLongitudeParam_Min();
        Double longitudeMax = driverLocatorQueryParameters.getLongitudeParam_Max();
        Long radius = driverLocatorQueryParameters.getRadius();
        Long limit = driverLocatorQueryParameters.getLimit();

        //entity.latitude > latitudeMin && entity.latitude < latitudeMax && entity.longitude > longitudeMin && entity.longitude < longitudeMax


        Query query = query((where("latitude").gt(latitudeMin))
                            .andOperator((where("latitude").lt(latitudeMax)))
                                .andOperator((where("longitude").gt(longitudeMin)))
                                        .andOperator((where("longitude").lt(longitudeMax))));

        Flux<DriverGeo> driverGeoFlux = reactiveMongoTemplate.find(query,DriverGeo.class);

        return driverGeoFlux.toStream().collect(Collectors.toList());
    }

}

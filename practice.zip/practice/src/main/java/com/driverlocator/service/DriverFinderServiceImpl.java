package com.driverlocator.service;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverLocatorModel;
import com.driverlocator.model.DriverLocatorQueryParameters;
import com.driverlocator.model.DriverLocatorRequestModel;
import com.driverlocator.model.DriverLocatorResponseModel;
import com.driverlocator.repository.DriverGeoRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DriverFinderServiceImpl implements DriverFinderService {

    Logger log = LoggerFactory.getLogger(DriverFinderServiceImpl.class);

    @Autowired
    DriverGeoRepository driverGeoRepository;

    @Autowired
    private ModelMapper modelMapper;

    /**
     *
     * @param driverLocatorRequestModel
     * @return
     */
    @Override
    public DriverLocatorResponseModel findMyNearestGoJeks(DriverLocatorRequestModel driverLocatorRequestModel){

        List<String> messages = validateLocatorRequestParameters(driverLocatorRequestModel);

        Boolean isValid = !messages.isEmpty() ? Boolean.FALSE : Boolean.TRUE;

        List<DriverLocatorModel> driverLocatorModels = isValid ? findDriversWithInRadius(driverLocatorRequestModel) : null;

        return DriverLocatorResponseModel.builder().nearestDrivers(driverLocatorModels).isValid(isValid).message(messages).build();
    }

    /**
     *
     * @param driverLocatorRequestModel
     * @return
     */
    public List<String> validateLocatorRequestParameters(DriverLocatorRequestModel driverLocatorRequestModel) {

        Double latitude_Parameter = driverLocatorRequestModel.getLatitude();

        Double longitude_Parameter = driverLocatorRequestModel.getLongitude();

        Long radius_Parameter = driverLocatorRequestModel.getRadius();

        List<String> messages = new ArrayList<>();

        if(90 < latitude_Parameter || latitude_Parameter < -90){
            messages.add("Latitude should be between +/- 90");
        }

        if(180 < longitude_Parameter || longitude_Parameter < -180){
            messages.add("Longitude should be between +/- 180");
        }

        if(radius_Parameter < 0 || radius_Parameter >10000){
            messages.add("Unacceptable radius value");
        }
        return messages;
    }

    /**
     *
     * @param driverGeo
     * @param latitudeParam
     * @param longitudeParam
     * @return distance
     */
   public Double computeDistance(DriverGeo driverGeo, Double latitudeParam, Double longitudeParam) {

        Double latitudeDelta = Math.abs(latitudeParam - driverGeo.getLatitude());

        Double longitudeDelta = Math.abs(longitudeParam - driverGeo.getLongitude());

        return Math.sqrt(latitudeDelta*latitudeDelta + longitudeDelta*longitudeDelta);
    }

    /**
     *
     * @param driverLocatorRequestModel
     * @return
     */
    @Override
    public List<DriverLocatorModel> findDriversWithInRadius(DriverLocatorRequestModel driverLocatorRequestModel) {

        Double latitudeParam = driverLocatorRequestModel.getLatitude();
        Double longitudeParam = driverLocatorRequestModel.getLongitude();
        Long radius = driverLocatorRequestModel.getRadius();

        List<DriverGeo>  driverGeosExtracted = driverGeoRepository.findNearestDriversWithInRadius
                (DriverLocatorQueryParameters.builder().latitude(latitudeParam).longitude(longitudeParam).radius(radius).build());

        log.info("driverGeos Extracted: {}, {}",driverGeosExtracted, driverGeosExtracted.size());

        //collect filtered entity's latitude and longitude & distance is computed
        return driverGeosExtracted.stream().map((driverGeoArgument) ->
        {
            DriverLocatorModel driverLocatorModel = modelMapper.map(driverGeoArgument, DriverLocatorModel.class );

            driverLocatorModel.setDistance(driverGeoArgument.getDistance()*1000);

            return driverLocatorModel;
        }).collect(Collectors.toList());
    }

}

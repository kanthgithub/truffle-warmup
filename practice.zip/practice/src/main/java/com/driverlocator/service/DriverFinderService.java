package com.driverlocator.service;

import com.driverlocator.model.DriverLocatorModel;
import com.driverlocator.model.DriverLocatorRequestModel;
import com.driverlocator.model.DriverLocatorResponseModel;

import java.util.List;

public interface DriverFinderService {

    public DriverLocatorResponseModel findMyNearestGoJeks(DriverLocatorRequestModel driverLocatorRequestModel);

    List<DriverLocatorModel> findDriversWithInRadius(DriverLocatorRequestModel driverLocatorRequestModel);
}

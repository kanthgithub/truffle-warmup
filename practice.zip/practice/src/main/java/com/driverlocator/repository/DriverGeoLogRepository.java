package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeoLog;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;

public interface DriverGeoLogRepository extends ReactiveMongoRepository<DriverGeoLog, String>,DriverGeoLogRepositoryCustom {


}


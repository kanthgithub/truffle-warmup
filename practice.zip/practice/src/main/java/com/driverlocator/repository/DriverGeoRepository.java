package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeo;
import org.springframework.data.geo.Distance;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import reactor.core.publisher.Flux;

public interface DriverGeoRepository extends ReactiveMongoRepository<DriverGeo, String>,DriverGeoRepositoryCustom {

    Flux<DriverGeo> findByLocationNear(Point locationPoint, Distance radius);

}


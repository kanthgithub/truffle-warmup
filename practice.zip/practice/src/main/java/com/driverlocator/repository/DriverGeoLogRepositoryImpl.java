package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeoLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Repository
public class DriverGeoLogRepositoryImpl implements DriverGeoLogRepositoryCustom {

    @Autowired
    private ReactiveMongoTemplate reactiveMongoTemplate;

    /**
     * @param userId
     * @return DriverGeo
     */
    @Override
    public Flux<DriverGeoLog> getDriverGeoLogsByUserId(Long userId) {

        Query query = query(where("userId").is(userId));

        return reactiveMongoTemplate.find(query,DriverGeoLog.class );
    }
}

package com.driverlocator.repository;


import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverLocatorQueryParameters;

import java.util.List;

/**
 * Record Driver's Geo
 * Create a new DriverGeo record in DriverGeo Collection
 */
public interface DriverGeoRepositoryCustom {

    /**
     *
     * @param userId
     * @return DriverGeo
     */
    public DriverGeo checkDriverEntry(Long userId) ;

    /**
     *
     * @param driverLocatorQueryParameters
     * @return List<DriverGeo>
     */
    List<DriverGeo> findNearestDriversWithInRadius(DriverLocatorQueryParameters driverLocatorQueryParameters);


}

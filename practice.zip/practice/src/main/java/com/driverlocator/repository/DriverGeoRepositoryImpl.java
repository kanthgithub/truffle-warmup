package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverLocatorQueryParameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.geo.Metrics;
import org.springframework.data.geo.Point;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.query.NearQuery;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Flux;

import java.util.List;
import java.util.stream.Collectors;

import static org.springframework.data.mongodb.core.aggregation.Aggregation.geoNear;
import static org.springframework.data.mongodb.core.aggregation.Aggregation.newAggregation;
import static org.springframework.data.mongodb.core.query.Criteria.where;
import static org.springframework.data.mongodb.core.query.Query.query;

@Repository
public class DriverGeoRepositoryImpl implements DriverGeoRepositoryCustom {

    Logger log = LoggerFactory.getLogger(DriverGeoRepositoryImpl.class);

    @Autowired
    private ReactiveMongoTemplate reactiveMongoTemplate;

    /**
     * @param userId
     * @return DriverGeo
     */
    @Override
    public DriverGeo checkDriverEntry(Long userId) {

        Query query = query(where("userId").is(userId));

        return reactiveMongoTemplate.findOne(query,DriverGeo.class ).block();
    }


/*    @Override
    public List<DriverGeo> findNearestDriversWithInRadius(DriverLocatorQueryParameters driverLocatorQueryParameters){


        // The following query would return documents from the places collection within the circle described by the center [ -74, 40.74 ]
        // with a radius of 100 miles:

        *//*db.places.find( { loc: { $geoWithin: { $centerSphere: [ [ -74, 40.74 ] ,
            100 / 3963.2 ] } } } )*//*

        *//**
         *     Point point = new Point(6.12343, 3.121211);
         Distance distance = new Distance(100, Metrics.KILOMETERS);
         Circle circle = new Circle(point, distance);
         Integer resultLimit = 20; //Limit to 20 records
         Criteria geoCriteria = Criteria.where("position").withinSphere(circle);
         Criteria timeCriteria = Criteria.where("time").gte(new Date());
         Query query = Query.query(geoCriteria);
         query.addCriteria(timeCriteria);
         query.fields().exclude("friends");
         mongoTemplate.find(query, Profile.class);
         *
         *
         *
         *//*
        log.info("queryParameters: {}",driverLocatorQueryParameters);

        GeoJsonPoint geoJsonPoint_Param = new GeoJsonPoint(driverLocatorQueryParameters.getLongitude(),driverLocatorQueryParameters.getLatitude());
        Distance distance = new Distance(driverLocatorQueryParameters.getRadius()/1000, Metrics.KILOMETERS);
        Circle circle = new Circle(geoJsonPoint_Param, distance);
        Criteria geoCriteria = Criteria.where("location").withinSphere(circle);

        log.info("criteria for location-WithIn-Sphere is: {} for circle: {}",geoCriteria,circle);

        Query query = Query.query(geoCriteria);

        Flux<DriverGeo> nearestDrivers =
                reactiveMongoTemplate.find(query, DriverGeo.class).limitRequest(10);

        return nearestDrivers.toStream().collect(Collectors.toList());
    }*/

    @Override
    public List<DriverGeo> findNearestDriversWithInRadius(DriverLocatorQueryParameters driverLocatorQueryParameters){

        Double radiusInKilometers = Double.valueOf(driverLocatorQueryParameters.getRadius())/1000;

        final NearQuery query = NearQuery.near(new Point(driverLocatorQueryParameters.getLongitude(), driverLocatorQueryParameters.getLatitude()), Metrics.KILOMETERS)
                .num(10)
                .minDistance(0, Metrics.KILOMETERS)
                .maxDistance(radiusInKilometers,Metrics.KILOMETERS)
                .spherical(true);

        final Aggregation a = newAggregation(geoNear(query, "distance"));

        final Flux<DriverGeo> results = reactiveMongoTemplate.aggregate(a, DriverGeo.class, DriverGeo.class);

        List<DriverGeo> driverGeos = results.toStream().collect(Collectors.toList());

        return driverGeos;
   }

}

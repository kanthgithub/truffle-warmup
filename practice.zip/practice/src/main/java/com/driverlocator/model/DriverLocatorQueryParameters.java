package com.driverlocator.model;

import lombok.*;

@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class DriverLocatorQueryParameters {

    Long radius ;
    Long limit;
    Double latitude;
    Double longitude;
}

package com.driverlocator.rest;

import com.driverlocator.model.DriverLocatorRequestModel;
import com.driverlocator.model.DriverLocatorResponseModel;
import com.driverlocator.model.ErrorModel;
import com.driverlocator.service.DriverFinderService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DriverFinderController {

    Logger log = LoggerFactory.getLogger(DriverFinderController.class);

    @Autowired
    private DriverFinderService driverFinderService;

    @RequestMapping(value = "/drivers",method = RequestMethod.GET)
    public ResponseEntity getDriverGeoLocationLogs(
            @RequestParam String latitude,
            @RequestParam String longitude,
            @RequestParam(required = false) String radius,
            @RequestParam(required = false) String limit){

        Double latitudeParam = Double.valueOf(latitude);
        Double longitudeParam = Double.valueOf(longitude);
        Long radiusParam = StringUtils.isNotBlank(radius) ? Long.valueOf(radius) : Long.valueOf(500);
        Integer limitParam = StringUtils.isNotBlank(limit) ? Integer.valueOf(limit) : Integer.valueOf(10);

        log.info("about to search for driver geo-coordinates: latitude: {}, longitude: {}, radius: {},limit: {} "
                ,latitudeParam,longitudeParam,radiusParam,limitParam);

        DriverLocatorRequestModel driverLocatorRequestModel =
                DriverLocatorRequestModel.builder().latitude(latitudeParam).longitude(longitudeParam)
                                                    .radius(radiusParam).limit(limitParam).build();

        DriverLocatorResponseModel driverLocatorResponseModel =
                driverFinderService.findMyNearestGoJeks(driverLocatorRequestModel);

        log.info("found {} drivers within geo-coordinates: latitude: {}, longitude: {}, radius: {},limit: {} "
                ,driverLocatorResponseModel,latitudeParam,longitudeParam,radiusParam,limitParam);

        HttpStatus responseStatus = null;

        List<String> messages = null;

        if(!driverLocatorResponseModel.getIsValid()){
            messages = driverLocatorResponseModel.getMessage();
            responseStatus = HttpStatus.UNPROCESSABLE_ENTITY;
        }else{
            responseStatus = HttpStatus.OK;
        }

        return !driverLocatorResponseModel.getIsValid() ?
                new ResponseEntity(ErrorModel.builder().errors(messages).build(),responseStatus)
        : ResponseEntity.ok(driverLocatorResponseModel.getNearestDrivers());
    }
}

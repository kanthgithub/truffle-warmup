package com.driverlocator.rest;

import com.driverlocator.model.DriverGeoLoggingResponseModel;
import com.driverlocator.model.DriverGeoModel;
import com.driverlocator.model.ErrorModel;
import com.driverlocator.service.DriverGeoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DriverGeoController {

    Logger log = LoggerFactory.getLogger(DriverGeoController.class);

    @Autowired
    DriverGeoService driverGeoService;

    @RequestMapping(value = "/drivers/{id}/location" , method = RequestMethod.PUT)
    @ResponseBody
    public ResponseEntity recordDriverGeoLocation(@PathVariable Long id,
                                                  @RequestBody DriverGeoModel driverGeoModel){

        log.info("recording location: {}",driverGeoModel);

        driverGeoModel.setUserId(id);

        HttpStatus responseStatus = null;

        List<String> messages = null;

        DriverGeoLoggingResponseModel driverGeoLoggingResponseModel = null;

        if(id < 1 || id > 50000){
            responseStatus = HttpStatus.NOT_FOUND;
        } else {

             driverGeoLoggingResponseModel =
                    driverGeoService.validateGeoLogEvent(driverGeoModel);

            if (!driverGeoLoggingResponseModel.getIsValid()) {
                messages = driverGeoLoggingResponseModel.getMessage();
                responseStatus = HttpStatus.UNPROCESSABLE_ENTITY;
            } else {
                driverGeoService.insertDriverLocationLogEvent(driverGeoModel);
                responseStatus = HttpStatus.OK;
            }
        }

        log.info("responseModel: {}",driverGeoLoggingResponseModel);

        return
                driverGeoLoggingResponseModel!=null ?
                !driverGeoLoggingResponseModel.getIsValid() ?
                new ResponseEntity(ErrorModel.builder().errors(messages).build(),responseStatus)
                : ResponseEntity.ok("") :new ResponseEntity(responseStatus);
    }


}

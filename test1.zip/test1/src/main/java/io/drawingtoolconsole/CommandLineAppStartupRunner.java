package io.drawingtoolconsole;

import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import io.drawingtoolconsole.console.service.DrawingToolCommandExecutionService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.Scanner;


@Component
public class CommandLineAppStartupRunner implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(CommandLineAppStartupRunner.class);

    @Autowired
    DrawingToolCommandExecutionService drawingToolCommandExecutionService;

    @Override
    public void run(String... args) {

        logger.info(
                "Application started with command-line arguments: {} . \n To kill this application, press Ctrl + C.",
                Arrays.toString(args));

        logger.info("EXECUTING : command line runner");

        Scanner scanner = new Scanner(System.in);

        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.ALIEN;

        do {

            System.out.print("enter command:");

            try {
                drawingToolConsoleCommand = DrawingToolConsoleCommand.parse(scanner.next());

                StringBuilder sb = drawingToolCommandExecutionService.executeDrawingCommand(scanner, drawingToolConsoleCommand);

                System.out.println(sb);
            }
            catch (Exception ex) {
                System.out.println(ex.getMessage());
            }
        }

        while (drawingToolConsoleCommand != DrawingToolConsoleCommand.QUIT);

        scanner.close();
        System.exit(0);
    }

}
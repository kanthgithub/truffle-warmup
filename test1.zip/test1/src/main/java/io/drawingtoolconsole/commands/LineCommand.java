package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;
import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class LineCommand implements Command
{
  private int xCoordinate1;
  private int yCoordinate1;
  private int xCoordinate2;
  private int yCoordinate2;


  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {
    canvasRenderer.addLine(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);
  }
}

package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;
import lombok.*;

@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CreateCommand implements Command
{
  private int width;
  private int height;

  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {
    canvasRenderer.createCanvas(width, height);
  }

}

package io.drawingtoolconsole.commands;

import io.drawingtoolconsole.CanvasRenderer;

public class AlienCommand implements Command
{
  @Override
  public void execute(CanvasRenderer canvasRenderer)
  {
    throw new RuntimeException("Cannot execute AlienCommands");
  }
}

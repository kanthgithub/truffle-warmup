package io.drawingtoolconsole.model;

import java.util.stream.IntStream;

public class DrawingCanvas
{
   final static char BLANK = ' ';

  private int width;
  private int height;
  private char[][] blocks;

  public DrawingCanvas(int _width, int _height)
  {
    width = _width;
    height = _height;

    blocks = new char[_width][_height];

    for (int widthIndex = 0; widthIndex < width; widthIndex++) {
      for (int heightIndex = 0; heightIndex < height; heightIndex++)
        blocks[widthIndex][heightIndex] = BLANK;
    }
  }

  public int width()
  {
    return width;
  }

  public int height()
  {
    return height;
  }

  public char[][] getBlocks(){
    return blocks.clone();
  }

  public void generateLineWithFillCharacter(int xCoordinate, int yCoordinate, char fillCharacter)
  {
    blocks[xCoordinate - 1][yCoordinate - 1] = fillCharacter;
  }

  public void fillCharactersInCoordinates(int xCoordinate, int yCoordinate, char fillCharacter) {

    if (validateCanvasCoordinates(xCoordinate,yCoordinate,height,width,blocks)) {

      blocks[xCoordinate - 1][yCoordinate - 1] = fillCharacter;

      fillCharactersInCoordinates(xCoordinate + 1, yCoordinate, fillCharacter);
      fillCharactersInCoordinates(xCoordinate - 1, yCoordinate, fillCharacter);
      fillCharactersInCoordinates(xCoordinate, yCoordinate + 1, fillCharacter);
      fillCharactersInCoordinates(xCoordinate, yCoordinate - 1, fillCharacter);
    }
  }

  public Boolean validateCanvasCoordinates(int xCoordinate, int yCoordinate, int height,int width, char[][] blocks ){

    return !(xCoordinate <= 0 || xCoordinate > width || yCoordinate <= 0 || yCoordinate > height || blocks[xCoordinate - 1][yCoordinate - 1] != BLANK);

  }

  public StringBuilder render()
  {
    StringBuilder sb = new StringBuilder();

    sb.append(buildCanvasHeader(width).toString());

    sb.append("\n");

    sb.append(buildCanvasBody(height,width,blocks).toString());

    sb.append(buildCanvasFooter(width).toString());

    return sb;
  }

  public static StringBuilder buildCanvasFooter(Integer width) {

    StringBuilder stringBuilder_Footer = new StringBuilder();

    IntStream.range(0, width + 2).forEach(number -> stringBuilder_Footer.append("_"));

    return stringBuilder_Footer;
  }

  public static StringBuilder buildCanvasHeader(Integer width) {

    StringBuilder stringBuilder_Header = new StringBuilder();

    IntStream.range(0, width + 2).forEach(number -> stringBuilder_Header.append("-"));

    return stringBuilder_Header;
  }

  public static StringBuilder buildCanvasBody(Integer height,Integer width,char[][] blocks) {

    StringBuilder stringBuilder_Body = new StringBuilder();

    //append data in canvas body
    for (int heightIndex = 0; heightIndex < height; heightIndex++) {

      stringBuilder_Body.append('|');

      for (int widthIndex = 0; widthIndex < width; widthIndex++) {
        stringBuilder_Body.append(blocks[widthIndex][heightIndex]);
      }

      stringBuilder_Body.append('|');

      stringBuilder_Body.append("\n");

    }

    return stringBuilder_Body;
  }

}

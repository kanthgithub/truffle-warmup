package io.drawingtoolconsole.model;


public interface Shape
{  
  void addShapeTo(DrawingCanvas drawingCanvas);
}

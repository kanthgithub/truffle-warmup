package io.drawingtoolconsole.configuration;

import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.console.enricher.*;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DrawingToolConsoleConfiguration {

    @Bean
    public CanvasRenderer canvasRenderer(){
        return new CanvasRenderer();
    }

    @Bean
    public CreateConsoleCommandArgumentEnricher createConsoleCommandArgumentEnricher(){
        return new CreateConsoleCommandArgumentEnricher();
    }

    @Bean
    public LineConsoleCommandArgumentEnricher lineConsoleCommandArgumentEnricher(){
        return new LineConsoleCommandArgumentEnricher();
    }

    @Bean
    public RectangleConsoleCommandArgumentEnricher rectangleConsoleCommandArgumentEnricher(){
        return new RectangleConsoleCommandArgumentEnricher();
    }

    @Bean
    public FillConsoleCommandArgumentEnricher fillConsoleCommandArgumentEnricher(){
        return new FillConsoleCommandArgumentEnricher();
    }

    @Bean
    public QuitConsoleCommandArgumentEnricher quitConsoleCommandArgumentEnricher(){
        return new QuitConsoleCommandArgumentEnricher();
    }

    @Bean
    public AlienConsoleCommandArgumentEnricher alienConsoleCommandArgumentEnricher(){
        return new AlienConsoleCommandArgumentEnricher();
    }


    @Bean
    public ConsoleCommandArgumentEnricherFactory consoleCommandArgumentEnricherFactory(){
        return  new ConsoleCommandArgumentEnricherFactory(createConsoleCommandArgumentEnricher(),lineConsoleCommandArgumentEnricher(),
                rectangleConsoleCommandArgumentEnricher(),fillConsoleCommandArgumentEnricher(),quitConsoleCommandArgumentEnricher(),
                alienConsoleCommandArgumentEnricher());
    }

}

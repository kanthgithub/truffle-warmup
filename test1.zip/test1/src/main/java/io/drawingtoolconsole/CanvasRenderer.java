package io.drawingtoolconsole;

import io.drawingtoolconsole.model.DrawingCanvas;
import io.drawingtoolconsole.model.Line;
import io.drawingtoolconsole.model.Rectangle;

/**
 * - Features:
 * - Creates DrawingCanvas to render the data within coordinates.
 * - Coordinates must be positive-Integers
 */
public class CanvasRenderer
{
  private DrawingCanvas drawingCanvas;

  public void createCanvas(int width,
                           int height)
  {
    if (width < 1 || height < 1)
      throw new IllegalArgumentException("DrawingCanvas dimensions must be positive");

    drawingCanvas = new DrawingCanvas(width, height);
  }


  public StringBuilder renderAsAString()
  {
    isAValidCanvas();

    return drawingCanvas.render();
  }

  private void isAValidCanvas()
  {
    if (drawingCanvas == null)
      throw new IllegalStateException("Invalid DrawingCanvas. DrawingCanvas cannot be empty.");
  }


  public void fillCoordinatesWithCharacters(int xCoordinate,
                                            int yCoordinate,
                                            char fillCharacter)
  {
    isAValidCanvas();
    if (xCoordinate < 1 || yCoordinate < 1)
      throw new IllegalArgumentException("renderer should render within drawingCanvas limits.");

    drawingCanvas.fillCharactersInCoordinates(xCoordinate, yCoordinate, fillCharacter);
  }

  public void addLine(int xCoordinate1,
                      int yCoordinate1,
                      int xCoordinate2,
                      int yCoordinate2)
  {
    isAValidCanvas();

    Line line = new Line(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);

    line.addShapeTo(drawingCanvas);
  }

  public void addRectangle(int xCoordinate1,
                           int yCoordinate1,
                           int xCoordinate2,
                           int yCoordinate2)
  {
    isAValidCanvas();

    Rectangle rectangle = new Rectangle(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);

    rectangle.addShapeTo(drawingCanvas);
  }

}

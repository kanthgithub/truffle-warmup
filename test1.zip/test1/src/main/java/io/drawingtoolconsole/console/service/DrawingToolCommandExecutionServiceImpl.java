package io.drawingtoolconsole.console.service;

import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import io.drawingtoolconsole.console.enricher.ConsoleCommandArgumentEnricherFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Scanner;

@Service
public class DrawingToolCommandExecutionServiceImpl implements DrawingToolCommandExecutionService{

    @Autowired
    private ConsoleCommandArgumentEnricherFactory consoleCommandArgumentEnricherFactory;

    @Autowired
    private CanvasRenderer canvasRenderer;

    /**
     *
     * @param scanner
     * @param drawingToolConsoleCommand
     * @return StringBuilder
     */
   public StringBuilder executeDrawingCommand(Scanner scanner,
                                               DrawingToolConsoleCommand drawingToolConsoleCommand){

        Command command = consoleCommandArgumentEnricherFactory
                                                .lookupCommandEnricher(drawingToolConsoleCommand)
                                                .enrichCommandWithScannerArguments(scanner);
        command.execute(canvasRenderer);

        return canvasRenderer.renderAsAString();
    }

}

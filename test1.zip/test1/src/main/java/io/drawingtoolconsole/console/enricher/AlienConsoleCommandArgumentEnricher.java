package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;

import java.util.Scanner;

public class AlienConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner)
  {
    scanner.nextLine();
    throw new IllegalArgumentException("Cannot process Alien Commands");
  }
}

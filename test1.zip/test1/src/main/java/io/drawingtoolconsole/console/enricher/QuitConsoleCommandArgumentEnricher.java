package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.QuitCommand;

import java.util.Scanner;

public class QuitConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner)
  {
    return new QuitCommand();
  }

}

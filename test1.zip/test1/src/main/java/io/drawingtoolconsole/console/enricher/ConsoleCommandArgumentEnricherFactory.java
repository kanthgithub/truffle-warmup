package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import lombok.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@Builder
public class ConsoleCommandArgumentEnricherFactory
{

  private final Logger log = LoggerFactory.getLogger(ConsoleCommandArgumentEnricherFactory.class);

  @Autowired
  private CreateConsoleCommandArgumentEnricher createConsoleCommandArgumentEnricher;

  @Autowired
  private LineConsoleCommandArgumentEnricher lineConsoleCommandArgumentEnricher;

  @Autowired
  private RectangleConsoleCommandArgumentEnricher rectangleConsoleCommandArgumentEnricher;

  @Autowired
  private FillConsoleCommandArgumentEnricher fillConsoleCommandArgumentEnricher;

  @Autowired
  private QuitConsoleCommandArgumentEnricher quitConsoleCommandArgumentEnricher;

  @Autowired
  private AlienConsoleCommandArgumentEnricher alienConsoleCommandArgumentEnricher;

  public ConsoleCommandArgumentEnricher lookupCommandEnricher(DrawingToolConsoleCommand drawingToolConsoleCommand)
  {

      ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher = alienConsoleCommandArgumentEnricher;

      if(drawingToolConsoleCommand == null){
          log.error("BLANK command received - returning as AlienCommand");
          return alienConsoleCommandArgumentEnricher;
      }

    switch (drawingToolConsoleCommand){

        case CREATE:{
            consoleCommandArgumentEnricher = createConsoleCommandArgumentEnricher;
            break;
        }

        case FILL:{
            consoleCommandArgumentEnricher = fillConsoleCommandArgumentEnricher;

            break;
        }

        case LINE:{
            consoleCommandArgumentEnricher = lineConsoleCommandArgumentEnricher;

            break;
        }

        case RECTANGLE:{
            consoleCommandArgumentEnricher = rectangleConsoleCommandArgumentEnricher;
            break;
        }

        case ALIEN:{
            consoleCommandArgumentEnricher = alienConsoleCommandArgumentEnricher;
            break;
        }

        case QUIT:{
            consoleCommandArgumentEnricher = quitConsoleCommandArgumentEnricher;
            break;
        }

        default:{
            break;
        }
    }


    return consoleCommandArgumentEnricher;
  }

}

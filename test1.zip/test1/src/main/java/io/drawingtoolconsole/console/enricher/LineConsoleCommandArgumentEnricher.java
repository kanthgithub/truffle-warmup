package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.LineCommand;

import java.util.Scanner;

public class LineConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner) {
      Integer xCoordinate1 = null;
      Integer yCoordinate1 = null;
      Integer xCoordinate2 = null;
      Integer yCoordinate2 = null;

      StringBuilder messageBuilder = new StringBuilder();

      try {
          if (scanner.hasNextInt()) {
              xCoordinate1 = scanner.nextInt();
          } else {
              messageBuilder.append(" Invalid xCoordinate1 for Line ");
          }

          if (xCoordinate1 != null && scanner.hasNext() && scanner.hasNextInt()) {
              yCoordinate1 = scanner.nextInt();
          } else {
              if ((xCoordinate1 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
                  messageBuilder.append(" Invalid yCoordinate1 for Line ");
              }
          }

          if (yCoordinate1 != null && scanner.hasNextInt()) {
              xCoordinate2 = scanner.nextInt();
          } else {
                  if ((yCoordinate1 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
                      messageBuilder.append(" Invalid xCoordinate2 for Line ");
              }
          }

          if (xCoordinate2 != null && scanner.hasNextInt()) {
              yCoordinate2 = scanner.nextInt();
          } else {
                  if ((xCoordinate2 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
                      messageBuilder.append(" Invalid yCoordinate2 for Line ");
              }
          }
      }
      catch (Exception ex){
        messageBuilder.append(" Invalid Coordinates for Line - Failed to parse arguments : Please correct arguments ");
     }

      if(messageBuilder.length()>0){
          throw new IllegalArgumentException(messageBuilder.toString());
      }

    return new LineCommand(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);
  }
}

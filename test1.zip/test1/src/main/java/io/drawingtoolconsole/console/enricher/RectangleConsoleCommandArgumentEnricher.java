package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.RectangleCommand;

import java.util.Scanner;

public class RectangleConsoleCommandArgumentEnricher implements ConsoleCommandArgumentEnricher
{
  @Override
  public Command enrichCommandWithScannerArguments(Scanner scanner)
  {
    Integer xCoordinate1 = null;
    Integer yCoordinate1 = null;
    Integer xCoordinate2 = null;
    Integer yCoordinate2 = null;

    StringBuilder messageBuilder = new StringBuilder();

    try {
      if (scanner.hasNextInt()) {
        xCoordinate1 = scanner.nextInt();
      } else {
        messageBuilder.append(" Invalid xCoordinate1 for Rectangle ");
      }

      if (xCoordinate1 != null && scanner.hasNext() && scanner.hasNextInt()) {
        yCoordinate1 = scanner.nextInt();
      } else {
        if ((xCoordinate1 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
          messageBuilder.append(" Invalid yCoordinate1 for Rectangle ");
        }
      }

      if (yCoordinate1 != null && scanner.hasNextInt()) {
        xCoordinate2 = scanner.nextInt();
      } else {
        if ((yCoordinate1 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
          messageBuilder.append(" Invalid xCoordinate2 for Rectangle ");
        }
      }

      if (xCoordinate2 != null && scanner.hasNextInt()) {
        yCoordinate2 = scanner.nextInt();
      } else {
        if ((xCoordinate2 != null && (!scanner.hasNext() || !scanner.hasNextInt()))) {
          messageBuilder.append(" Invalid yCoordinate2 for Rectangle ");
        }
      }
    }
    catch (Exception ex){
      messageBuilder.append(" Invalid Coordinates for Rectangle - Failed to parse arguments : Please correct arguments ");
    }

    if(messageBuilder.length()>0){
      throw new IllegalArgumentException(messageBuilder.toString());
    }

    return new RectangleCommand(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);
  }
}

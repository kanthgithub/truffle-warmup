package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import io.drawingtoolconsole.console.DrawingToolConsoleCommand;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class ConsoleCommandArgumentEnricherFactoryTest {

    @Autowired
    private ConsoleCommandArgumentEnricherFactory consoleCommandArgumentEnricherFactory;

    @Test
    public void assert_For_Successful_Lookup_Of_CreateConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.CREATE;

        //when
       ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
               consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  CreateConsoleCommandArgumentEnricher);
    }


    @Test
    public void assert_For_Successful_Lookup_Of_FillConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.FILL;

        //when
        ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
                consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  FillConsoleCommandArgumentEnricher);
    }

    @Test
    public void assert_For_Successful_Lookup_Of_LineConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.LINE;

        //when
        ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
                consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  LineConsoleCommandArgumentEnricher);
    }

    @Test
    public void assert_For_Successful_Lookup_Of_RectangleConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.RECTANGLE;

        //when
        ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
                consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  RectangleConsoleCommandArgumentEnricher);
    }

    @Test
    public void assert_For_Successful_Lookup_Of_QuitConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = DrawingToolConsoleCommand.QUIT;

        //when
        ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
                consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  QuitConsoleCommandArgumentEnricher);
    }

    @Test
    public void assert_For_Successful_Lookup_Of_InvalidConsole_Command_Enricher() {

        //given
        DrawingToolConsoleCommand drawingToolConsoleCommand = null;

        //when
        ConsoleCommandArgumentEnricher consoleCommandArgumentEnricher =
                consoleCommandArgumentEnricherFactory.lookupCommandEnricher(drawingToolConsoleCommand);

        //then
        assertNotNull(consoleCommandArgumentEnricher);
        assertTrue(consoleCommandArgumentEnricher instanceof  AlienConsoleCommandArgumentEnricher);
    }



}

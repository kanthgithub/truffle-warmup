package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.RectangleCommand;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class RectangleConsoleCommandArgumentEnricherTest {

    @Autowired
    RectangleConsoleCommandArgumentEnricher rectangleConsoleCommandArgumentEnricher;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
    }

   @Test
    public void assert_enrichCommandWithScannerArguments(){

        //given
        String data = "R 1 2 6 6";

        scanner = generateScannerWithTestData(data);

        //when
        command_Actual =
                rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);


        //then
        assertNotNull(command_Actual);
        assertTrue(command_Actual instanceof RectangleCommand);

       RectangleCommand rectangleCommand_Actual = (RectangleCommand)command_Actual;

        assertEquals(1,rectangleCommand_Actual.getXCoordinate1());
        assertEquals(2,rectangleCommand_Actual.getYCoordinate1());
        assertEquals(6,rectangleCommand_Actual.getXCoordinate2());
        assertEquals(6,rectangleCommand_Actual.getYCoordinate2());
    }

    @Test
    public void assert_ScannerException_For_Invalid_FourthCordinate_In_Rectangle(){

        //given
        String data = "R 1 2 6 A";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid yCoordinate2 for Rectangle ",errorMessage);
    }

    @Test
    public void assert_ScannerException_For_Invalid_ThirdCordinate_In_Rectangle(){

        //given
        String data = "R 1 2 A 1";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid xCoordinate2 for Rectangle ",errorMessage);
    }

    @Test
    public void assert_ScannerException_For_Invalid_SecondCordinate_In_Rectangle(){

        //given
        String data = "R 1 X 2 9";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid yCoordinate1 for Rectangle ",errorMessage);
    }

    @Test
    public void assert_ScannerException_For_Invalid_FirstCordinate_In_Rectangle(){

        //given
        String data = "R Z 2 1 3";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid xCoordinate1 for Rectangle ",errorMessage);
    }

    @Test
    public void assert_For_ExceptionMessage_With_All_InvalidScannerArguments(){

        //given
        String data = "R A B C D";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    rectangleConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid xCoordinate1 for Rectangle ",errorMessage);
    }

}

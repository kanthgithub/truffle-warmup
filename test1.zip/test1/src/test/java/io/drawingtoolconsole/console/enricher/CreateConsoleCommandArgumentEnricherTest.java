package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.CreateCommand;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class CreateConsoleCommandArgumentEnricherTest {

    @Autowired
    CreateConsoleCommandArgumentEnricher createConsoleCommandArgumentEnricher;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
    }

   @Test
    public void assert_enrichCommandWithScannerArguments(){

        //given
        String data = "C 10 12";

        scanner = generateScannerWithTestData(data);

        //when
        command_Actual =
                createConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);

        //then
        assertNotNull(command_Actual);
        assertTrue(command_Actual instanceof CreateCommand);

       CreateCommand createCommand_Actual = (CreateCommand)command_Actual;

        assertEquals(10,createCommand_Actual.getWidth());
        assertEquals(12,createCommand_Actual.getHeight());
    }


    @Test
    public void assert_ScannerException_For_Invalid_Width_For_Console(){

        //given
        String data = "C A 12";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    createConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid width for Console Creation ",errorMessage);
    }


    @Test
    public void assert_ScannerException_For_Invalid_Height_For_Console(){

        //given
        String data = "C 12 B";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    createConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid height for Console Creation ",errorMessage);
    }

}

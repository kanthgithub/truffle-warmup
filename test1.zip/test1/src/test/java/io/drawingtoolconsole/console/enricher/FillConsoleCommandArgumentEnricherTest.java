package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.FillCommand;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class FillConsoleCommandArgumentEnricherTest {

    @Autowired
    FillConsoleCommandArgumentEnricher fillConsoleCommandArgumentEnricher;

    Scanner scanner;

    Command command_Actual;

    String errorMessage;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
        errorMessage = null;
    }

   @Test
    public void assert_enrichCommandWithScannerArguments(){

        //given
        String data = "B 10 12 o";

        scanner = generateScannerWithTestData(data);

        //when
        command_Actual =
                fillConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);

        //then
        assertNotNull(command_Actual);
        assertTrue(command_Actual instanceof FillCommand);

       FillCommand fillCommand_Actual = (FillCommand)command_Actual;

        assertEquals(10,fillCommand_Actual.getXCoordinate());
        assertEquals(12,fillCommand_Actual.getYCoordinate());
        assertEquals('o',fillCommand_Actual.getColor());
    }

    @Test
    public void assert_ScannerException_For_Invalid_Color_For_Fill(){

        //given
        String data = "B 10 12";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    fillConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid color for Fill ",errorMessage);
    }

    @Test
    public void assert_ScannerException_For_Invalid_XCoordinate_For_Fill(){

        //given
        String data = "B A 12 o";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    fillConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid xCoordinate for Fill ",errorMessage);
    }


    @Test
    public void assert_ScannerException_For_Invalid_YCoordinate_For_Fill(){

        //given
        String data = "B 10 A o";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    fillConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid yCoordinate for Fill ",errorMessage);
    }

    @Test
    public void assert_For_ExceptionMessage_With_All_InvalidScannerArguments(){

        //given
        String data = "B A B";

        scanner = generateScannerWithTestData(data);

        //when
        try {
            command_Actual =
                    fillConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);
        }catch (Exception ex){
            errorMessage = ex.getMessage();
        }

        //then
        assertNull(command_Actual);
        assertNotNull(errorMessage);
        assertEquals(" Invalid xCoordinate for Fill ",errorMessage);
    }

}

package io.drawingtoolconsole.console.enricher;

import io.drawingtoolconsole.commands.Command;
import io.drawingtoolconsole.commands.QuitCommand;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.annotation.DirtiesContext.ClassMode;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Scanner;

import static io.drawingtoolconsole.utils.ScannerTestUtils.generateScannerWithTestData;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = ClassMode.AFTER_EACH_TEST_METHOD)
public class QuitConsoleCommandArgumentEnricherTest {

    @Autowired
    QuitConsoleCommandArgumentEnricher quitConsoleCommandArgumentEnricher;

    Scanner scanner;

    Command command_Actual;

    @Before
    public void prepareForTests(){
        scanner = null;
        command_Actual = null;
    }

   @Test
    public void assert_QuitConsoleCommandArgument_Enricher(){

        //given
        String data = "Q";

        scanner = generateScannerWithTestData(data);

        //when
        command_Actual =
                quitConsoleCommandArgumentEnricher.enrichCommandWithScannerArguments(scanner);

        //then
        assertNotNull(command_Actual);
        assertTrue(command_Actual instanceof QuitCommand);
    }

}

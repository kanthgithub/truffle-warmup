package io.drawingtoolconsole.cucumber.stepDefs;

import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Map;

import static org.springframework.boot.test.context.SpringBootTest.WebEnvironment.RANDOM_PORT;

@RunWith(SpringRunner.class)
@ContextConfiguration(classes = {
        DrawingConsoleToolApplicationTestConfiguration.class})
@SpringBootTest(webEnvironment = RANDOM_PORT)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
@Ignore
public class DrawingConsoleToolStepDefinition  {

    Scenario currentScenario;

    @Before
    public void setup(Scenario scenario) throws Exception {
        currentScenario = scenario;
    }

    @When("^I open LimitHub Snapshot tab on MLS GUI$")
    public void iOpenLimitHubSnapshotTabOnMlsGui() {

    }

    @Then("^Response should contain (\\d+) utilization snapshots$")
    public void responseShouldContainUtilizationSnapshots(int numSnapshots) throws Throwable {

    }

    @When("^User selects \"(.*)\" and clicks Send Limit button from LimitHub Snapshots tab$")
    public void userSelectsDBSAndClicksSendLimitButton(String clientName) throws Throwable {

    }

    @When("^User selects \"(.*)\" and clicks Send Limit and Utilization button from LimitHub Snapshots tab$")
    public void updateClientLimitAndUtilization(String clientName) throws Throwable {

    }

    @When("^User selects \"(.*)\" and clicks Remove Limit button from LimitHub Snapshots tab$")
    public void removeClientLimt(String clientName) throws Throwable {

    }

    @Then("^System should send (\\d+) messages to LimitHub$")
    public void systemShouldSendMessagesToLimitHub(int numMessages) throws Exception {

    }

    @Then("^Client Limit message should be published to LimitHub for client \"([^\"]*)\" as below$")
    public void limitUpdatesShouldBeSentAsBelow(String clientName, Map<String, String> expectedMessage) throws Exception {

    }

    @Then("^Client Utilization message should be published to LimitHub for client \"([^\"]*)\" as below$")
    public void clientUtilizationMessagePublished(String clientName, Map<String, String> expectedMessage) throws Exception {

    }

    @Then("^User access should be denied to send client limit to LimitHub$")
    public void userAccessShouldBeDeniedToSendClientLimitToLimitHub() throws Throwable {
    }

    @Test
    public void dummy() {
    }

    @And("^User should have access to send and remove limit to LimitHub$")
    public void userShouldHaveAccessToSendLimitToLimitHub() throws Throwable {

    }


    @And("^The system should update Limit CarveOut = ([0-9\\.]+) for client \"(.*)\"$")
    public void udpate_client_carveout(BigDecimal limitCarveOut, String clientName) throws Throwable {

    }


}

package io.drawingtoolconsole;

import io.drawingtoolconsole.configuration.DrawingConsoleToolApplicationTestConfiguration;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class CanvasRendererTest {

    @Autowired
    CanvasRenderer canvasRenderer;

    @Test
    public void assert_Canvas_Rendering(){

        //given
        Integer xCoordinate1 = 2;
        Integer yCoordinate1 = 6;
        Integer xCoordinate2 = 2;
        Integer yCoordinate2 = 12;

        Integer canvas_Width = 12;
        Integer canvas_Height = 20;

        canvasRenderer.createCanvas(canvas_Width,canvas_Height);

        canvasRenderer.addLine(xCoordinate1, yCoordinate1, xCoordinate2, yCoordinate2);

        //when
        StringBuilder lineRendered_Actual = canvasRenderer.renderAsAString();

        String lineRendered_Expected =
                "--------------\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "| x          |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "|            |\n" +
                "______________";

        //then
        assertNotNull(lineRendered_Actual);
        assertEquals(lineRendered_Expected,lineRendered_Actual.toString() );
    }

    public void createCanvas_With_Parameters(Integer width,Integer height){
        canvasRenderer.createCanvas(width, height);
    }



}

package io.drawingtoolconsole.configuration;


import io.drawingtoolconsole.CanvasRenderer;
import io.drawingtoolconsole.console.enricher.*;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = DrawingConsoleToolApplicationTestConfiguration.class)
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_EACH_TEST_METHOD)
public class DrawingToolConfigurationTest {

    @Autowired
    DrawingToolConsoleConfiguration drawingToolConsoleConfiguration;

    @Test
    public void assert_For_All_Dependencies_From_Configuration(){

       //checks
       Object object_AlienCommand_Enricher_Actual =
               drawingToolConsoleConfiguration.alienConsoleCommandArgumentEnricher();

       //then
        assertNotNull(object_AlienCommand_Enricher_Actual);
        assertTrue(object_AlienCommand_Enricher_Actual instanceof AlienConsoleCommandArgumentEnricher);


        //checks
        Object object_CanvasRenderer_Actual =
                drawingToolConsoleConfiguration.canvasRenderer();

        //then
        assertNotNull(object_CanvasRenderer_Actual);
        assertTrue(object_CanvasRenderer_Actual instanceof CanvasRenderer);


        //checks
        Object object_consoleCommandArgumentEnricherFactory_Actual =
                drawingToolConsoleConfiguration.consoleCommandArgumentEnricherFactory();

        //then
        assertNotNull(object_consoleCommandArgumentEnricherFactory_Actual);
        assertTrue(object_consoleCommandArgumentEnricherFactory_Actual instanceof ConsoleCommandArgumentEnricherFactory);


        //checks
        Object object_createConsoleCommandArgumentEnricher_Actual =
                drawingToolConsoleConfiguration.createConsoleCommandArgumentEnricher();

        //then
        assertNotNull(object_createConsoleCommandArgumentEnricher_Actual);
        assertTrue(object_createConsoleCommandArgumentEnricher_Actual instanceof CreateConsoleCommandArgumentEnricher);


        //checks
        Object object_fillConsoleCommandArgumentEnricher_Actual =
                drawingToolConsoleConfiguration.fillConsoleCommandArgumentEnricher();

        //then
        assertNotNull(object_fillConsoleCommandArgumentEnricher_Actual);
        assertTrue(object_fillConsoleCommandArgumentEnricher_Actual instanceof FillConsoleCommandArgumentEnricher);


        //checks
        Object object_lineConsoleCommandArgumentEnricher_Actual =
                drawingToolConsoleConfiguration.lineConsoleCommandArgumentEnricher();

        //then
        assertNotNull(object_lineConsoleCommandArgumentEnricher_Actual);
        assertTrue(object_lineConsoleCommandArgumentEnricher_Actual instanceof LineConsoleCommandArgumentEnricher);

        //checks
        Object object_quitConsoleCommandArgumentEnricher_Actual =
                drawingToolConsoleConfiguration.quitConsoleCommandArgumentEnricher();

        //then
        assertNotNull(object_quitConsoleCommandArgumentEnricher_Actual);
        assertTrue(object_quitConsoleCommandArgumentEnricher_Actual instanceof QuitConsoleCommandArgumentEnricher);

        //checks
        Object object_rectangleConsoleCommandArgumentEnricher_Actual =
                drawingToolConsoleConfiguration.rectangleConsoleCommandArgumentEnricher();

        //then
        assertNotNull(object_rectangleConsoleCommandArgumentEnricher_Actual);
        assertTrue(object_rectangleConsoleCommandArgumentEnricher_Actual instanceof RectangleConsoleCommandArgumentEnricher);
    }

}

package io.drawingtoolconsole.model;

import org.junit.Test;

import static io.drawingtoolconsole.model.DrawingCanvas.BLANK;
import static org.junit.Assert.*;

public class DrawingCanvasTest {

    @Test
    public void assert_Drawing_Canvas_Initialization(){

        //given
        Integer width = 10;
        Integer height = 12;

        //when
        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);

        //then
        assertNotNull(drawingCanvas);
        assertEquals(height.intValue(),drawingCanvas.height() );
        assertEquals(width.intValue(),drawingCanvas.width() );
    }

    @Test
    public void assert_Coordinates_On_Drawing_Canvas(){

        //given
        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);


        int xCoordinate_Shape = 9;
        int yCoordinate_Shape = 7;
        char[][] blocks = new char[width][height];
        blocks[xCoordinate_Shape-1][yCoordinate_Shape-1] = BLANK;

        //when
        Boolean does_CoordinatesFitIntoCanvas =
                drawingCanvas.validateCanvasCoordinates(xCoordinate_Shape,yCoordinate_Shape,height ,width, blocks);

        //then
        assertNotNull(does_CoordinatesFitIntoCanvas);
        assertTrue(does_CoordinatesFitIntoCanvas);
    }

    @Test
    public void assert_For_Validation_Failure_For_Coordinates_On_Drawing_Canvas(){

        //given
        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);


        int xCoordinate_Shape = 9;
        int yCoordinate_Shape = 7;
        char[][] blocks = new char[width][height];
        blocks[xCoordinate_Shape-1][yCoordinate_Shape-1] = '0';

        //when
        Boolean does_CoordinatesFitIntoCanvas =
                drawingCanvas.validateCanvasCoordinates(xCoordinate_Shape,yCoordinate_Shape,height ,width, blocks);

        //then
        assertNotNull(does_CoordinatesFitIntoCanvas);
        assertFalse(does_CoordinatesFitIntoCanvas);
    }

    @Test
    public void assert_Fill_Canvas_With_Characters_Within_Coordinates(){

        //given
        Integer xCoordinate = 2;
        Integer yCoordinate = 6;
        char fillCharacter = 'o';

        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);

        //when
        drawingCanvas.fillCharactersInCoordinates(xCoordinate,yCoordinate ,fillCharacter );

        //then
        char[][] blocksWithFilledCharacters = drawingCanvas.getBlocks();

        assertTrue(blocksWithFilledCharacters.length>0);

        for(int blockIndex = 0; blockIndex <yCoordinate;blockIndex++){
            assertTrue(blocksWithFilledCharacters[xCoordinate][blockIndex] == fillCharacter);
        }
    }

    @Test
    public void assert_Generate_Line_With_Fill_Characters(){

        //given
        Integer xCoordinate = 2;
        Integer yCoordinate = 6;
        char fillCharacter = 'o';

        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);

        //when
        drawingCanvas.generateLineWithFillCharacter(xCoordinate,yCoordinate ,fillCharacter );

        //then
        char[][] blocksWithFilledCharacters = drawingCanvas.getBlocks();

        assertTrue(blocksWithFilledCharacters.length>0);

        assertTrue(blocksWithFilledCharacters[xCoordinate-1][yCoordinate-1] == fillCharacter);
    }


    @Test
    public void assert_Render_Canvas_Blocks(){

        //given
        Integer xCoordinate = 2;
        Integer yCoordinate = 6;
        char fillCharacter = 'o';

        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);

        drawingCanvas.fillCharactersInCoordinates(xCoordinate,yCoordinate ,fillCharacter );

        String renderedText_Expected =
                "------------\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "|oooooooooo|\n" +
                "____________";

        //when
        StringBuilder renderedText_Actual = drawingCanvas.render();

        //then
        assertNotNull(renderedText_Actual);
        assertNotNull(renderedText_Actual.toString());
        assertEquals(renderedText_Expected,renderedText_Actual.toString() );
    }



    @Test
    public void assert_Render_Canvas_Body_From_Blocks(){

        //given
        Integer xCoordinate = 2;
        Integer yCoordinate = 6;
        char fillCharacter = 'o';

        Integer width = 10;
        Integer height = 12;

        DrawingCanvas drawingCanvas = getADrawingCanvasFromParameters(width,height);
        drawingCanvas.fillCharactersInCoordinates(xCoordinate,yCoordinate ,fillCharacter );

        String renderedText_Expected =
                      "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n" +
                              "|oooooooooo|\n";
        //when
        StringBuilder renderedBody_Actual = DrawingCanvas.buildCanvasBody(height,width,drawingCanvas.getBlocks() );

        //then
        assertNotNull(renderedBody_Actual);
        assertNotNull(renderedBody_Actual.toString());
        assertEquals(renderedText_Expected,renderedBody_Actual.toString() );
    }

    @Test
    public void assert_Build_Canvas_Header(){

        //given
        Integer width = 12;

        //when
        StringBuilder stringBuilder_Header = DrawingCanvas.buildCanvasHeader(width);

        //then
        assertNotNull(stringBuilder_Header);
        assertEquals("--------------", stringBuilder_Header.toString());
    }

    @Test
    public void assert_Build_Canvas_Footer(){

        //given
        Integer width = 12;

        //when
        StringBuilder stringBuilder_Header = DrawingCanvas.buildCanvasFooter(width);

        //then
        assertNotNull(stringBuilder_Header);
        assertEquals("______________", stringBuilder_Header.toString());
    }


    public DrawingCanvas getADrawingCanvasFromParameters(Integer width, Integer height){

        return new DrawingCanvas(width,height);
    }
}

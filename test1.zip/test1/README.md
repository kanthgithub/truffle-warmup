# Drawing Tool Console:

## Tech-Stack:
<ol><li>Algorithm is implemented in jdk-8 and runs on jre-8</li>
<li>Junit & Cucumber used for unit-testing</li>
<li>Maven project</li><ol>

## Features:
1. Create a new canvas
2. Start drawing on the canvas by issuing various commands
3. Quit

```
At the moment, the program should support the following commands:
```

<table>
<tr><th>Command</th><th>Command Execution and Output<th></tr>
<tr><td>C w h</td></td>Should create a new canvas of width w and height h.</td></tr>
<tr><td>L xCoordinate1 yCoordinate1 xCoordinate2 yCoordinate2</td><td><p>Should create a new line from (xCoordinate1,yCoordinate1) to (xCoordinate2,yCoordinate2).<p>Currently only horizontal or vertical lines are supported.<p>Horizontal and vertical lines will be drawn using the 'xCoordinate' character.</td></tr>
<tr><td>R xCoordinate1 yCoordinate1 xCoordinate2 yCoordinate2 </td><td><p>Should create a new rectangle, whose upper left corner is (xCoordinate1,yCoordinate1) and lower right corner is (xCoordinate2,yCoordinate2).<p>Horizontal and vertical lines will be drawn using the 'xCoordinate' character.</td></tr>
<tr><td>B xCoordinate yCoordinate c</td><td><p>Should fillCoordinatesWithCharacters the entire area connected to (xCoordinate,yCoordinate) with "colour" c.<p>The behaviour of this is the same as that of the "bucket fill" tool in paint programs.</td></tr>
<tr><td>Q </td><td>Should quit the program.</td></tr>
</table>

### Sample I/O

 - Below is a sample run of the program. User input is prefixed with ’enter command:’.

   - enter command: C 20 4

        ```

        ----------------------
        |                    |
        |                    |
        |                    |
        |                    |
        ______________________

        ```

   - enter command: L 1 2 6 2

        ```
        ----------------------
        |                    |
        |xxxxxx              |
        |                    |
        |                    |
        ______________________

        ```

   - enter command: L 6 3 6 4

        ```
        ----------------------
        |                    |
        |xxxxxx              |
        |     x              |
        |     x              |
        ______________________

        ```

   - enter command: R 16 1 20 3

        ```
        ----------------------
        |               xxxxx|
        |xxxxxx         x   x|
        |     x         xxxxx|
        |     x              |
        ______________________

        ```

   - enter command: B 10 3 o

        ```
        ----------------------
        |oooooooooooooooxxxxx|
        |xxxxxxooooooooox   x|
        |     xoooooooooxxxxx|
        |     xoooooooooooooo|
        ______________________

        ```

   - enter command: Q


## Design:




## Testing:



### Unit-Testing:

Command-line Runner has to be excluded to unit-test components:

```
package: io.drawingtoolconsole.console.enricher
```

<b>Classes:

<ol>
<li>ConsoleCommandArgumentEnricherFactoryTest.java</li>
<li>ConsoleCommandArgumentEnricherTest.java</li>
<li>LineCommandArgumentEnricherTest.java</li>
<li>RectangleCommandArgumentEnricherTest.java</li>
<li>FillCommandArgumentEnricherTest.java</li>
<li>QuitCommandArgumentEnricherTest.java</li>
<li>AlienCommandArgumentEnricherTest.java</li>
</ol>

```
package: io.drawingtoolconsole.console.service
```

<b>Classes:

<ol>
<li>DrawingToolCommandExecutionServiceImplTest.java</li>
</ol>

#### Procedure followed to exclude loading commandLineRunner for above mentioned tests:

<ul><li>
You can define a test configuration in the same package as your application that looks exactly the same,</li>
<li>except that it excludes beans implementing CommandLineRunner.</li>
<li>The key here is @ComponentScan.excludeFilters:</li><ul>

```java

@Configuration
@ComponentScan(excludeFilters = @ComponentScan.Filter(type = FilterType.ASSIGNABLE_TYPE, value = CommandLineRunner.class))
@EnableAutoConfiguration
public class TestApplicationConfiguration {
}
Then, just replace the configuration on your test:

@RunWith(SpringJUnit4ClassRunner.class)
@SpringBootTest(classes = TestApplicationConfiguration.class)
public class ConsoleCommandArgumentEnricherFactoryTest {
    ...
}

```
<pre>
No CommandLineRunner will be executed now, because they are not part of the configuration.

package com.driverlocator.service;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverGeoModel;
import com.driverlocator.repository.DriverGeoRepository;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.UUID;

@Service
public class DriverGeoServiceImpl implements DriverGeoService {

    Logger log = LoggerFactory.getLogger(DriverGeoServiceImpl.class);

    @Autowired
    private DriverGeoRepository driverGeoRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public Mono<DriverGeo> insertDriverLocationLogEvent(DriverGeoModel driverGeoModel) {

        DriverGeo driverGeo =
                modelMapper.map(driverGeoModel, DriverGeo.class);

        driverGeo.setId(UUID.randomUUID().toString());

        return driverGeoRepository.insert(driverGeo);
    }

    @Override
    public Mono<DriverGeo> findDriverByUserId(Long userId) {
        return driverGeoRepository.getDriverGeoByUserId(userId);
    }


}

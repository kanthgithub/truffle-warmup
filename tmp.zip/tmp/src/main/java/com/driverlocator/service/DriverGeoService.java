package com.driverlocator.service;

import com.driverlocator.entity.DriverGeo;
import com.driverlocator.model.DriverGeoModel;
import reactor.core.publisher.Mono;

public interface DriverGeoService {

    Mono<DriverGeo> insertDriverLocationLogEvent(DriverGeoModel driverGeoModel) ;

    Mono<DriverGeo> findDriverByUserId(Long userId);
}

package com.driverlocator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.reactive.config.EnableWebFlux;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableWebFlux
@EnableSwagger2
@ComponentScan("com.driverlocator")
public class DriverLocatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(DriverLocatorApplication.class, args);
    }
}

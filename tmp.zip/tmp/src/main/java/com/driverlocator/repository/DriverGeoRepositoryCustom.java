package com.driverlocator.repository;


import com.driverlocator.entity.DriverGeo;
import reactor.core.publisher.Mono;

/**
 * Record Driver's Geo
 * Create a new DriverGeo record in DriverGeo Collection
 */
public interface DriverGeoRepositoryCustom {


    /**
     *
     * @param userId
     * @return DriverGeo
     */
    public Mono<DriverGeo> getDriverGeoByUserId(Long userId);


}

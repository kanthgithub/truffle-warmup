package com.driverlocator.repository;

import com.driverlocator.entity.DriverGeo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.ReactiveMongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;
import reactor.core.publisher.Mono;

@Repository
public class DriverGeoRepositoryImpl implements DriverGeoRepositoryCustom {

    @Autowired
    private ReactiveMongoTemplate reactiveMongoTemplate;

    /**
     * @param userId
     * @return DriverGeo
     */
    @Override
    public Mono<DriverGeo> getDriverGeoByUserId(Long userId) {
        return reactiveMongoTemplate.findOne(new Query(where("_id").is(person.getId())),DriverGeo.class );
    }
}

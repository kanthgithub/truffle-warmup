# Chef Locator API
API to locate nearest chefs
API for chefs to record their current location